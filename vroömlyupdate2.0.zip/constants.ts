
import { Ride, User, LocationPoint, RouteDefinition } from './types';

export const APP_NAME = "Vroömly";

// --- Mock Database ---

export const MOCK_USERS: User[] = [
  { id: 'u1', name: 'Saad Khan', email: 'saad@bahria.edu.pk', password: '123', role: 'DRIVER', avatar: 'https://picsum.photos/seed/saad/100/100', averageRating: 4.8, totalReviews: 42, totalRides: 120, phone: '0300-1111111' },
  { id: 'u2', name: 'Amnah Ali', email: 'amnah@student.bahria.edu.pk', password: '123', role: 'PASSENGER', avatar: 'https://picsum.photos/seed/amnah/100/100', averageRating: 4.9, totalReviews: 12, totalRides: 45, phone: '0333-2222222' },
  { id: 'u3', name: 'Bilal Sheikh', email: 'bilal@student.bahria.edu.pk', password: '123', role: 'PASSENGER', avatar: 'https://picsum.photos/seed/bilal/100/100', averageRating: 4.5, totalReviews: 8, totalRides: 23, phone: '0345-3333333' },
  { id: 'u4', name: 'Zara Malik', email: 'zara@student.bahria.edu.pk', password: '123', role: 'PASSENGER', avatar: 'https://picsum.photos/seed/zara/100/100', averageRating: 5.0, totalReviews: 3, totalRides: 15, phone: '0321-4444444' },
  { id: 'u5', name: 'Dr. Usman', email: 'usman@faculty.bahria.edu.pk', password: '123', role: 'DRIVER', avatar: 'https://picsum.photos/seed/usman/100/100', averageRating: 4.9, totalReviews: 89, totalRides: 310, phone: '0300-5555555' },
];

// Routes Context: Bahria University E-8 Islamabad

export const CAMPUS_LOCATION: LocationPoint = { id: 'bu_campus', name: 'Bahria Uni E-8 Campus', lat: 33.71, lng: 73.02, isStop: true };

export const ROUTES: RouteDefinition[] = [
  {
    id: 'route_f10',
    name: 'F-10 / F-11 Route',
    points: [
      { id: 'p1', name: 'F-11 Markaz', lat: 33.68, lng: 72.98, isStop: true },
      { id: 'p2', name: 'F-10 Roundabout', lat: 33.69, lng: 73.00, isStop: true },
      { id: 'p3', name: 'E-9 Checkpost', lat: 33.70, lng: 73.01, isStop: false },
      CAMPUS_LOCATION
    ]
  },
  {
    id: 'route_blue',
    name: 'Blue Area / G-7 Route',
    points: [
      { id: 'b1', name: 'Metro Station (Stock Exchange)', lat: 33.70, lng: 73.05, isStop: true },
      { id: 'b2', name: 'G-7 Markaz', lat: 33.71, lng: 73.06, isStop: true },
      { id: 'b3', name: 'F-7 Jinnah Super', lat: 33.72, lng: 73.05, isStop: true },
      CAMPUS_LOCATION
    ]
  },
  {
    id: 'route_rawalpindi',
    name: 'Saddar Rawalpindi Route',
    points: [
      { id: 'r1', name: 'Saddar Metro', lat: 33.59, lng: 73.05, isStop: true },
      { id: 'r2', name: 'Murree Road', lat: 33.62, lng: 73.06, isStop: false },
      { id: 'r3', name: 'Faizabad', lat: 33.66, lng: 73.08, isStop: true },
      CAMPUS_LOCATION
    ]
  }
];

// Mock Active Rides
export const MOCK_RIDES: Ride[] = [
  {
    id: 'ride_101',
    driverId: 'u1',
    vehicleName: 'Honda Civic (Black)',
    vehicleType: 'SEDAN',
    capacity: 4,
    direction: 'TO_CAMPUS',
    routeId: 'route_f10',
    startTime: '08:15 AM',
    isActive: true,
    status: 'SCHEDULED',
    currentLocationIndex: 0,
    passengers: [
       { ...MOCK_USERS[1], role: 'PASSENGER', status: 'PRESENT', pickupLocation: 'F-11 Markaz' }
    ],
    chatMessages: [],
    reviews: []
  },
  {
    id: 'ride_102',
    driverId: 'u5',
    vehicleName: 'Toyota HiAce (Yellow)',
    vehicleType: 'BUS',
    capacity: 12,
    direction: 'FROM_CAMPUS',
    routeId: 'route_blue',
    startTime: '04:30 PM',
    isActive: true,
    status: 'SCHEDULED',
    currentLocationIndex: 0,
    passengers: [],
    chatMessages: [],
    reviews: []
  }
];

export const STATUS_COLORS = {
  PENDING: 'bg-gray-100 text-gray-600',
  COMING: 'bg-bahria-gold text-white',
  PRESENT: 'bg-bahria-blue text-white',
  ABSENT: 'bg-danger-red text-white'
};

export const STATUS_LABELS = {
  PENDING: 'Waiting',
  COMING: 'On Way',
  PRESENT: 'In Car',
  ABSENT: 'Absent'
};
