import React, { useState, useEffect } from 'react';
import { User, Ride, Passenger, PassengerStatus, GroupMessage, RideStatus, UserRole, RideDirection, Cancellation, AppSettings, Alert } from './types';
import { MOCK_USERS, MOCK_RIDES, ROUTES, CAMPUS_LOCATION, STATUS_LABELS } from './constants';
import { Button } from './components/Button';
import { StatusBadge } from './components/StatusBadge';
import { RideAssistant } from './components/RideAssistant';
import { RideGroupChat } from './components/RideGroupChat';
import { RideMap } from './components/RideMap';
import { RatingModal } from './components/RatingModal';
import { CancellationModal } from './components/CancellationModal';
import { AuthScreen } from './components/AuthScreen';
import { HamburgerButton, HamburgerDrawer } from './components/HamburgerMenu';
import { ComplaintsView, PremiumView } from './components/MenuViews';
import { 
  Users, MapPin, Navigation, LogOut, Car, 
  CheckCircle2, PlayCircle, StopCircle, Plus, ArrowLeft,
  LayoutDashboard, History, User as UserIcon, Settings, Edit, Bell, Shield, UserX, Calendar, Clock, ChevronRight,
  Lock, Globe, HelpCircle, Megaphone, AlertTriangle, X, Crown, Home
} from 'lucide-react';

// --- Types for Internal Navigation ---
type ViewType = 'HOME' | 'HISTORY' | 'PROFILE' | 'CREATE_RIDE' | 'SETTINGS' | 'COMPLAINTS' | 'PREMIUM';

// --- Sub-Components ---

// --- Modern Bottom Navigation Dock ---
const BottomNav: React.FC<{ current: ViewType; onChange: (view: ViewType) => void; isDriver: boolean }> = ({ current, onChange }) => (
  <div className="absolute bottom-0 left-0 right-0 p-4 z-40 pointer-events-none">
    <div className="bg-bahria-blue/90 backdrop-blur-xl border border-white/10 mx-auto max-w-sm rounded-[2rem] shadow-float p-2 flex items-center justify-between pointer-events-auto">
      {['HOME', 'HISTORY', 'PROFILE'].map((view) => {
        const isActive = current === view;
        const Icon = view === 'HOME' ? LayoutDashboard : view === 'HISTORY' ? History : UserIcon;
        
        return (
          <button 
            key={view}
            onClick={() => onChange(view as ViewType)}
            className={`flex-1 flex flex-col items-center justify-center h-14 rounded-[1.5rem] transition-all duration-300 relative overflow-hidden group ${isActive ? 'bg-white/10 text-white' : 'text-blue-200 hover:text-white'}`}
          >
            <Icon size={24} strokeWidth={isActive ? 2.5 : 2} className={`transition-transform duration-300 ${isActive ? 'scale-110 -translate-y-1' : ''}`} />
            {isActive && <div className="absolute bottom-2 w-1 h-1 bg-bahria-gold rounded-full"></div>}
          </button>
        );
      })}
    </div>
  </div>
);

// --- Settings View ---
const SettingsView: React.FC<{ 
  onMenuClick: () => void;
  settings: AppSettings;
  onUpdate: (s: Partial<AppSettings>) => void;
}> = ({ onMenuClick, settings, onUpdate }) => {
  
  const handleToggleNotifications = () => {
    onUpdate({ notifications: !settings.notifications });
  };

  const handleToggle2FA = () => {
    onUpdate({ twoFactorAuth: !settings.twoFactorAuth });
  };

  const handleToggleLanguage = () => {
    onUpdate({ language: settings.language === 'English' ? 'Urdu' : 'English' });
  };

  const handleChangePassword = () => {
    alert("Password change feature would open here.");
  };

  const handleHelp = () => {
    alert("Connecting to Bahria Student Support...");
  };

  return (
    <div className="min-h-full bg-truck-cream pb-32 animate-fade-in">
       <div className="pt-8 px-6 pb-6 flex items-start justify-between">
        <div>
           <h2 className="text-3xl font-extrabold text-bahria-blue">Settings</h2>
           <p className="text-gray-400 font-medium">App preferences</p>
        </div>
        <div className="bg-white rounded-full shadow-sm">
           <HamburgerButton onClick={onMenuClick} />
        </div>
      </div>
      
      <main className="px-5 space-y-6">
         {/* Account Section */}
         <section>
            <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3 ml-2">Account</h3>
            <div className="bg-white rounded-[24px] shadow-soft overflow-hidden">
               <button onClick={handleChangePassword} className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors border-b border-gray-100">
                  <div className="flex items-center gap-3">
                     <div className="w-8 h-8 rounded-full bg-blue-50 text-bahria-blue flex items-center justify-center"><Lock size={16} /></div>
                     <span className="font-bold text-gray-700">Change Password</span>
                  </div>
                  <ChevronRight size={16} className="text-gray-300" />
               </button>
               <div className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-3">
                     <div className="w-8 h-8 rounded-full bg-blue-50 text-bahria-blue flex items-center justify-center"><Shield size={16} /></div>
                     <span className="font-bold text-gray-700">Two-Factor Auth</span>
                  </div>
                   <button onClick={handleToggle2FA} className={`w-10 h-6 rounded-full p-1 transition-colors ${settings.twoFactorAuth ? 'bg-bahria-blue' : 'bg-gray-200'}`}>
                    <div className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${settings.twoFactorAuth ? 'translate-x-4' : ''}`} />
                  </button>
               </div>
            </div>
         </section>
         
         {/* Preferences */}
         <section>
            <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3 ml-2">Preferences</h3>
            <div className="bg-white rounded-[24px] shadow-soft overflow-hidden">
               <div className="w-full flex items-center justify-between p-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                     <div className="w-8 h-8 rounded-full bg-yellow-50 text-yellow-600 flex items-center justify-center"><Bell size={16} /></div>
                     <span className="font-bold text-gray-700">Notifications</span>
                  </div>
                  <button onClick={handleToggleNotifications} className={`w-10 h-6 rounded-full p-1 transition-colors ${settings.notifications ? 'bg-bahria-blue' : 'bg-gray-200'}`}>
                    <div className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${settings.notifications ? 'translate-x-4' : ''}`} />
                  </button>
               </div>
               <button onClick={handleToggleLanguage} className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-3">
                     <div className="w-8 h-8 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center"><Globe size={16} /></div>
                     <span className="font-bold text-gray-700">Language</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-gray-400">{settings.language}</span>
                    <ChevronRight size={16} className="text-gray-300" />
                  </div>
               </button>
            </div>
         </section>

         {/* Support */}
         <section>
            <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3 ml-2">Support</h3>
            <div className="bg-white rounded-[24px] shadow-soft overflow-hidden">
               <button onClick={handleHelp} className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-3">
                     <div className="w-8 h-8 rounded-full bg-green-50 text-green-600 flex items-center justify-center"><HelpCircle size={16} /></div>
                     <span className="font-bold text-gray-700">Help Center</span>
                  </div>
                  <ChevronRight size={16} className="text-gray-300" />
               </button>
            </div>
         </section>
         
         <div className="text-center pt-4 pb-8">
            <p className="text-xs text-gray-400 font-medium">Vroömly Version 2.2.0</p>
         </div>
      </main>
    </div>
  );
};

// --- User Profile & Settings ---
const UserProfileView: React.FC<{ 
  user: User; 
  rideCount: number; 
  onLogout: () => void;
  onUpdateProfile: (data: Partial<User>) => void;
  onMenuClick: () => void;
}> = ({ user, rideCount, onLogout, onUpdateProfile, onMenuClick }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user.name);
  const [phone, setPhone] = useState(user.phone || '');

  const handleSave = () => {
    onUpdateProfile({ name, phone });
    setIsEditing(false);
  };

  return (
    <div className="min-h-full bg-truck-cream pb-32 animate-fade-in">
      <div className="bg-gradient-to-b from-bahria-blue to-bahria-blue-light text-white p-6 pt-12 rounded-b-[40px] relative shadow-lg overflow-hidden">
        {/* Menu Button */}
        <div className="absolute top-6 left-6 z-20">
            <div className="bg-white/10 rounded-full backdrop-blur-md">
                <HamburgerButton onClick={onMenuClick} />
            </div>
        </div>

        {/* Profile Header */}
        <div className="flex flex-col items-center relative z-10">
           <div className="relative mb-4">
             {/* Dynamic background glow based on Premium */}
             <div className={`absolute inset-0 blur-xl opacity-40 rounded-full animate-pulse-soft ${user.isPremium ? 'bg-bahria-gold' : 'bg-blue-400'}`}></div>
             
             <img 
               src={user.avatar} 
               className={`relative w-28 h-28 rounded-full shadow-xl object-cover bg-white ${user.isPremium ? 'border-4 border-bahria-gold' : 'border-4 border-white/20'}`} 
               alt="Profile" 
             />
             
             {/* Edit Button */}
             <button onClick={() => setIsEditing(!isEditing)} className="absolute bottom-0 right-0 bg-white text-bahria-blue p-2 rounded-full shadow-lg active:scale-90 transition-transform hover:bg-gray-100">
               <Edit size={14} />
             </button>

             {/* Premium Crown Badge */}
             {user.isPremium && (
               <div className="absolute -top-2 right-0 bg-bahria-gold text-bahria-blue p-1.5 rounded-full border-2 border-white shadow-md animate-bounce">
                 <Crown size={16} fill="currentColor" />
               </div>
             )}
           </div>
           
           <h2 className="text-2xl font-bold flex items-center gap-2">
             {user.name}
           </h2>
           
           <div className="flex items-center gap-2 mt-2">
             <span className="text-blue-200 text-sm font-medium bg-white/10 px-4 py-1 rounded-full backdrop-blur-md">
               {user.role === 'DRIVER' ? 'Captain' : 'Passenger'}
             </span>
             {user.isPremium && (
               <span className="text-bahria-blue text-xs font-bold bg-bahria-gold px-3 py-1 rounded-full shadow-lg shadow-bahria-gold/20 flex items-center gap-1">
                 PRO <Crown size={10} fill="currentColor" />
               </span>
             )}
           </div>
        </div>
      </div>

      <div className="px-5 mt-6 space-y-4">
        {/* Stats Row */}
        <div className="flex gap-4">
           <div className="flex-1 bg-white p-4 rounded-3xl shadow-soft flex flex-col items-center justify-center">
              <span className="text-2xl font-bold text-bahria-blue">{rideCount}</span>
              <span className="text-xs text-gray-400 font-bold uppercase tracking-wider">Rides</span>
           </div>
           <div className="flex-1 bg-white p-4 rounded-3xl shadow-soft flex flex-col items-center justify-center">
              <span className="text-2xl font-bold text-bahria-blue flex items-center gap-1">{user.averageRating} <span className="text-bahria-gold text-lg">★</span></span>
              <span className="text-xs text-gray-400 font-bold uppercase tracking-wider">Rating</span>
           </div>
        </div>

        {/* Info Card */}
        <div className="bg-white rounded-[32px] p-6 shadow-card border border-white/50">
          <div className="flex justify-between items-center mb-6">
             <h3 className="font-bold text-gray-800 text-lg">Details</h3>
             {isEditing && <button onClick={handleSave} className="text-xs bg-bahria-blue text-white px-3 py-1 rounded-full font-bold">Save</button>}
          </div>
          <div className="space-y-6">
            <div className="group">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wide ml-1">Full Name</label>
              <input 
                disabled={!isEditing} 
                value={name} 
                onChange={(e) => setName(e.target.value)}
                className={`w-full p-3 rounded-xl font-medium transition-colors ${isEditing ? 'bg-gray-50 text-bahria-blue border border-blue-100' : 'bg-transparent text-gray-800 border-none px-0'}`} 
              />
            </div>
            <div className="group">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wide ml-1">Phone</label>
              <input 
                disabled={!isEditing} 
                value={phone} 
                onChange={(e) => setPhone(e.target.value)}
                placeholder={isEditing ? "Add phone number" : "No phone number"}
                className={`w-full p-3 rounded-xl font-medium transition-colors ${isEditing ? 'bg-gray-50 text-bahria-blue border border-blue-100' : 'bg-transparent text-gray-800 border-none px-0'}`} 
              />
            </div>
          </div>
        </div>

        <Button variant="danger" fullWidth onClick={onLogout} className="py-4 rounded-3xl !text-red-500 !bg-red-50 border-none shadow-none">
          <LogOut size={20} className="mr-2" /> Log Out
        </Button>
      </div>
    </div>
  );
};

// --- Ride History View ---
const RideHistoryView: React.FC<{ user: User; rides: Ride[]; onMenuClick: () => void }> = ({ user, rides, onMenuClick }) => {
  // Sort by latest completed time, fallback to start time, then default to now for filtering
  const history = rides
    .filter(r => (r.status === 'COMPLETED') && (r.driverId === user.id || r.passengers.some(p => p.id === user.id)))
    .sort((a, b) => {
      const tA = new Date(a.completedAt || a.startTime).getTime();
      const tB = new Date(b.completedAt || b.startTime).getTime();
      return tB - tA; // Newest first
    });

  return (
    <div className="min-h-full bg-truck-cream pb-32 animate-fade-in">
      <div className="pt-8 px-6 pb-6 flex items-start justify-between">
        <div>
           <h2 className="text-3xl font-extrabold text-bahria-blue">History</h2>
           <p className="text-gray-400 font-medium">Your past journeys</p>
        </div>
        <div className="bg-white rounded-full shadow-sm">
           <HamburgerButton onClick={onMenuClick} />
        </div>
      </div>

      <main className="px-5 space-y-4">
        {history.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 opacity-50">
            <History size={64} className="text-gray-300 mb-4" />
            <p className="font-medium text-gray-400">No past rides</p>
          </div>
        ) : (
          history.map((ride, idx) => {
             const route = ROUTES.find(r => r.id === ride.routeId);
             const isDriver = ride.driverId === user.id;
             const completionDate = ride.completedAt ? new Date(ride.completedAt) : new Date();
             const dateStr = completionDate.toLocaleDateString('default', { day: 'numeric', month: 'short' });
             const timeStr = completionDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

             return (
               <div key={ride.id} className="bg-white rounded-[24px] p-5 shadow-soft flex items-center gap-4 animate-slide-up" style={{animationDelay: `${idx * 100}ms`}}>
                 {/* Date Box */}
                 <div className="bg-gray-50 border border-gray-100 rounded-2xl w-16 h-16 flex flex-col items-center justify-center shrink-0">
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{completionDate.toLocaleString('default', { month: 'short' })}</span>
                    <span className="text-xl font-extrabold text-bahria-blue">{completionDate.getDate()}</span>
                 </div>
                 
                 {/* Details */}
                 <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                       <h3 className="font-bold text-gray-900 truncate text-sm">{route?.name || "Custom Route"}</h3>
                       {isDriver ? (
                         <span className="text-[9px] bg-bahria-blue text-white px-1.5 py-0.5 rounded-full font-bold uppercase">Captain</span>
                       ) : (
                         <span className="text-[9px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded-full font-bold uppercase">Passenger</span>
                       )}
                    </div>
                    <div className="flex items-center justify-between">
                       <p className="text-xs text-gray-400 font-medium flex items-center gap-1">
                         <Clock size={12} /> {timeStr}
                       </p>
                       <p className="text-xs font-bold text-gray-800">PKR 150</p>
                    </div>
                 </div>

                 {/* Status Icon */}
                 <div className="bg-green-50 text-green-600 p-2 rounded-full border border-green-100 shadow-sm">
                    <CheckCircle2 size={18} />
                 </div>
               </div>
             );
          })
        )}
      </main>
    </div>
  );
};

// --- Driver Dashboard ---
const DriverDashboard: React.FC<{ 
  user: User; 
  activeRides: Ride[]; 
  onCreateClick: () => void; 
  onManageRide: (id: string) => void;
  onNavigate: (view: ViewType) => void;
  onMenuClick: () => void;
}> = ({ user, activeRides, onCreateClick, onManageRide, onNavigate, onMenuClick }) => {
  const myActiveRides = activeRides.filter(r => r.driverId === user.id && r.status !== 'COMPLETED');
  // Real-time calculation of completed rides
  const totalRides = activeRides.filter(r => r.driverId === user.id && r.status === 'COMPLETED').length;

  return (
    <div className="min-h-full bg-truck-cream pb-32 animate-fade-in">
      {/* Dynamic Header */}
      <header className="bg-bahria-blue text-white p-6 pt-10 rounded-b-[40px] shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2"></div>
        
        {/* Top Row: Menu & Profile */}
        <div className="relative z-10 flex justify-between items-center mb-6">
          <div className="bg-white/10 rounded-full">
             <HamburgerButton onClick={onMenuClick} />
          </div>
          <button 
            onClick={() => onNavigate('PROFILE')} 
            className="focus:outline-none transition-transform active:scale-95 rounded-full relative"
          >
             {user.isPremium && <div className="absolute -inset-1 bg-bahria-gold rounded-full animate-pulse-soft blur-sm"></div>}
            <img 
              src={user.avatar} 
              className={`relative w-10 h-10 rounded-full object-cover ${user.isPremium ? 'border-2 border-bahria-gold' : 'border-2 border-white/20'}`} 
              alt="User" 
            />
          </button>
        </div>

        <div className="relative z-10">
            <p className="text-blue-200 text-sm font-medium">Welcome back,</p>
            <div className="flex items-center gap-2">
              <h1 className="text-3xl font-bold tracking-tight">{user.name.split(' ')[0]}</h1>
              {user.isPremium && <Crown size={24} className="text-bahria-gold fill-bahria-gold animate-bounce" />}
            </div>
        </div>
        
        {/* Total Rides Widget (Real-time) */}
        <div className="mt-8 bg-white/10 backdrop-blur-md rounded-3xl p-5 border border-white/10 flex items-center justify-between">
           <div>
             <div className="text-xs text-blue-200 uppercase tracking-wider font-bold mb-1">Total Rides</div>
             <div className="text-3xl font-bold">{totalRides}</div>
           </div>
           <div className="w-10 h-10 bg-bahria-gold rounded-full flex items-center justify-center shadow-lg shadow-bahria-gold/30">
              <Car size={24} className="text-white" />
           </div>
        </div>
      </header>

      <main className="px-5 -mt-6 relative z-20 space-y-6">
        {/* Action Button */}
        <button 
          onClick={onCreateClick}
          className="w-full bg-white p-6 rounded-[32px] shadow-card flex items-center justify-between active:scale-[0.98] transition-transform"
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-bahria-blue to-blue-900 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-blue-900/20">
              <Car size={28} />
            </div>
            <div className="text-left">
              <h4 className="font-bold text-gray-900 text-lg">Create Ride</h4>
              <p className="text-xs text-gray-500 font-medium">Start a new route</p>
            </div>
          </div>
          <div className="bg-gray-50 w-10 h-10 rounded-full flex items-center justify-center"><ChevronRight size={20} className="text-gray-400" /></div>
        </button>

        <div>
          <h3 className="font-bold text-gray-800 text-lg mb-3 px-2">Scheduled Rides</h3>
          {myActiveRides.length === 0 ? (
            <div className="text-center py-10 bg-white rounded-3xl border border-dashed border-gray-200">
              <p className="text-gray-400 text-sm font-medium">No rides today</p>
            </div>
          ) : (
            <div className="space-y-4">
              {myActiveRides.map((ride, idx) => {
                 const route = ROUTES.find(r => r.id === ride.routeId);
                 return (
                   <div key={ride.id} className="bg-white p-5 rounded-[28px] shadow-soft border border-gray-50 relative overflow-hidden group animate-slide-up" style={{animationDelay: `${idx * 150}ms`}}>
                      <div className="absolute top-0 right-0 bg-green-100 text-green-700 text-[10px] font-bold px-3 py-1.5 rounded-bl-2xl">
                         {ride.status === 'IN_PROGRESS' ? 'LIVE' : ride.startTime}
                      </div>
                      <div className="mb-3">
                        <h4 className="font-bold text-gray-900 text-lg">{route?.name}</h4>
                        <p className="text-xs text-gray-500">{ride.vehicleName}</p>
                      </div>
                      <div className="flex items-center justify-between mt-4">
                         <div className="flex -space-x-2">
                           {ride.passengers.slice(0,3).map(p => (
                             <img key={p.id} src={p.avatar} className="w-8 h-8 rounded-full border-2 border-white" />
                           ))}
                           {ride.passengers.length > 3 && <div className="w-8 h-8 rounded-full bg-gray-100 border-2 border-white flex items-center justify-center text-[10px] font-bold text-gray-500">+{ride.passengers.length - 3}</div>}
                         </div>
                         <Button size="sm" onClick={() => onManageRide(ride.id)} className="rounded-xl">Manage</Button>
                      </div>
                   </div>
                 );
              })}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

// --- Ride Browser ---
const RideBrowser: React.FC<{ 
  user: User; 
  availableRides: Ride[]; 
  allUsers: User[];
  onJoinRide: (rideId: string) => void;
  currentRideId?: string | null;
  onReturnToRide: (rideId: string) => void;
  onNavigate: (view: ViewType) => void;
  onMenuClick: () => void;
}> = ({ user, availableRides, allUsers, onJoinRide, currentRideId, onReturnToRide, onNavigate, onMenuClick }) => {
  const [filter, setFilter] = useState<RideDirection | 'ALL'>('ALL');

  const filteredRides = availableRides.filter(r => 
    r.status === 'SCHEDULED' && 
    (filter === 'ALL' || r.direction === filter) &&
    r.passengers.length < r.capacity
  );

  return (
    <div className="min-h-full bg-truck-cream pb-32 animate-fade-in">
      <div className="bg-white pt-8 pb-6 px-6 rounded-b-[40px] shadow-soft sticky top-0 z-30">
        
        {/* Header Row */}
        <div className="flex justify-between items-start mb-6">
          <div className="flex items-center gap-3">
             <div className="mt-1">
               <HamburgerButton onClick={onMenuClick} />
             </div>
             <div>
                <div className="flex items-center gap-1.5 mb-1 text-bahria-gold">
                  <MapPin size={16} fill="currentColor" />
                  <span className="text-xs font-bold uppercase tracking-wide">Location</span>
                </div>
                <h2 className="text-xl font-bold text-gray-900">Bahria E-8</h2>
             </div>
          </div>
          <button 
            onClick={() => onNavigate('PROFILE')} 
            className="focus:outline-none transition-transform active:scale-95 rounded-full relative"
          >
             {user.isPremium && <div className="absolute -inset-1 bg-bahria-gold rounded-full animate-pulse-soft blur-sm"></div>}
            <img 
              src={user.avatar} 
              className={`relative w-10 h-10 rounded-full object-cover shadow-sm ${user.isPremium ? 'border-2 border-bahria-gold' : 'border-2 border-gray-100'}`} 
            />
            {user.isPremium && <div className="absolute -bottom-1 -right-1 bg-bahria-gold text-white p-0.5 rounded-full border border-white"><Crown size={8} fill="currentColor"/></div>}
          </button>
        </div>

        {/* Filter Pills */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
          {['ALL', 'TO_CAMPUS', 'FROM_CAMPUS'].map(f => (
            <button 
              key={f}
              onClick={() => setFilter(f as any)} 
              className={`px-5 py-2.5 rounded-full text-xs font-bold whitespace-nowrap transition-all ${filter === f ? 'bg-bahria-blue text-white shadow-lg shadow-bahria-blue/20' : 'bg-gray-100 text-gray-500'}`}
            >
              {f === 'ALL' ? 'All Rides' : f === 'TO_CAMPUS' ? 'To Campus' : 'From Campus'}
            </button>
          ))}
        </div>
      </div>

      <main className="px-5 pt-6 space-y-5">
        {currentRideId && (
          <div onClick={() => onReturnToRide(currentRideId)} className="bg-gradient-to-r from-truck-teal to-teal-600 rounded-[28px] p-1 shadow-lg cursor-pointer transform hover:scale-[1.02] transition-all">
             <div className="bg-white/10 backdrop-blur-md p-4 rounded-[24px] flex justify-between items-center text-white">
                <div className="flex items-center gap-4">
                  <div className="bg-white/20 p-2.5 rounded-full animate-pulse"><Navigation size={20} /></div>
                  <div><p className="font-bold">Ride Active</p><p className="text-xs opacity-80">Tap to view</p></div>
                </div>
                <ChevronRight size={20} />
             </div>
          </div>
        )}

        <div className="flex justify-between items-end px-2">
          <h3 className="font-bold text-gray-800 text-lg">Available</h3>
          <span className="text-xs font-bold text-gray-400">{filteredRides.length} rides</span>
        </div>

        {filteredRides.length === 0 ? (
           <div className="text-center py-20 opacity-50">
             <Car size={48} className="mx-auto mb-4 text-gray-300" />
             <p className="text-gray-500 font-medium text-sm">No rides found</p>
           </div>
        ) : (
          filteredRides.map((ride, idx) => {
            const route = ROUTES.find(r => r.id === ride.routeId);
            const driver = allUsers.find(u => u.id === ride.driverId);
            const seatsLeft = ride.capacity - ride.passengers.length;
            const isMyRide = ride.id === currentRideId;

            return (
              <div key={ride.id} className="bg-white rounded-[32px] p-5 shadow-soft border border-gray-100 flex flex-col gap-4 animate-slide-up" style={{animationDelay: `${idx * 100}ms`}}>
                {/* Ticket Header */}
                <div className="flex items-start justify-between border-b border-dashed border-gray-200 pb-4">
                   <div className="flex gap-3">
                      <img src={driver?.avatar} className="w-12 h-12 rounded-2xl object-cover bg-gray-100" />
                      <div>
                        <h4 className="font-bold text-gray-900 flex items-center gap-1">
                          {driver?.name}
                          {driver?.isPremium && <Crown size={12} className="text-bahria-gold fill-bahria-gold" />}
                        </h4>
                        <div className="flex items-center gap-1 text-xs text-gray-500 mt-0.5">
                           <span className="bg-yellow-100 text-yellow-700 px-1.5 rounded font-bold">★ {driver?.averageRating}</span>
                           <span>• {ride.vehicleName}</span>
                        </div>
                      </div>
                   </div>
                   <div className="text-right">
                      <p className="text-lg font-bold text-bahria-blue">{ride.startTime}</p>
                      <p className="text-[10px] font-bold text-gray-400 uppercase">Departure</p>
                   </div>
                </div>

                {/* Route Info */}
                <div className="flex items-center gap-3">
                   <div className={`p-2.5 rounded-2xl ${ride.direction === 'TO_CAMPUS' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
                      <ArrowLeft size={18} className={ride.direction === 'TO_CAMPUS' ? 'rotate-180' : ''} />
                   </div>
                   <div>
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Route</p>
                      <p className="text-sm font-bold text-gray-800 line-clamp-1">{route?.name}</p>
                   </div>
                </div>

                {/* Action */}
                <div className="flex items-center justify-between">
                   <div className="flex items-center gap-2">
                     <Users size={16} className="text-gray-400" />
                     <span className="text-sm font-bold text-gray-600">{seatsLeft} <span className="text-xs font-normal">seats left</span></span>
                   </div>
                   <Button 
                     size="sm" 
                     onClick={() => onJoinRide(ride.id)} 
                     disabled={isMyRide} 
                     className={`rounded-xl px-6 ${isMyRide ? 'bg-gray-100 !text-gray-400 !shadow-none' : ''}`}
                   >
                     {isMyRide ? 'Booked' : 'Book Now'}
                   </Button>
                </div>
              </div>
            );
          })
        )}
      </main>
    </div>
  );
};

// --- Create Ride Screen ---
const CreateRideScreen: React.FC<{
  user: User;
  onCreate: (data: Partial<Ride>) => void;
  onCancel: () => void;
  onMenuClick: () => void;
}> = ({ user, onCreate, onCancel, onMenuClick }) => {
  const [routeId, setRouteId] = useState(ROUTES[0].id);
  const [time, setTime] = useState('08:00 AM');
  const [direction, setDirection] = useState<RideDirection>('TO_CAMPUS');
  const [capacity, setCapacity] = useState(4);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const route = ROUTES.find(r => r.id === routeId);
    if (!route) return;

    onCreate({
      driverId: user.id,
      routeId,
      startTime: time,
      direction,
      capacity,
      vehicleName: "Honda Civic (Black)", // Mock default or add input
      vehicleType: "SEDAN",
      isActive: true,
      status: 'SCHEDULED',
      passengers: [],
      chatMessages: [],
      currentLocationIndex: 0,
      reviews: []
    });
  };

  return (
    <div className="min-h-full bg-truck-cream pb-32 animate-fade-in">
       {/* Header */}
       <div className="pt-8 px-6 pb-6 flex items-start justify-between">
        <div>
           <h2 className="text-3xl font-extrabold text-bahria-blue">New Ride</h2>
           <p className="text-gray-400 font-medium">Plan your route</p>
        </div>
        <div className="bg-white rounded-full shadow-sm">
           <HamburgerButton onClick={onMenuClick} />
        </div>
      </div>

      <main className="px-5">
        <form onSubmit={handleSubmit} className="bg-white rounded-[32px] p-6 shadow-card space-y-6">
           <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wide ml-1">Route</label>
              <select 
                value={routeId}
                onChange={(e) => setRouteId(e.target.value)}
                className="w-full bg-gray-50 border-none rounded-xl p-4 font-bold text-gray-800 outline-none focus:ring-2 focus:ring-bahria-blue"
              >
                {ROUTES.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
              </select>
           </div>

           <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wide ml-1">Direction</label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setDirection('TO_CAMPUS')}
                  className={`flex-1 py-3 rounded-xl text-xs font-bold transition-all border ${direction === 'TO_CAMPUS' ? 'bg-bahria-blue text-white border-bahria-blue' : 'bg-gray-50 text-gray-500 border-transparent'}`}
                >
                  To Campus
                </button>
                <button
                  type="button"
                  onClick={() => setDirection('FROM_CAMPUS')}
                  className={`flex-1 py-3 rounded-xl text-xs font-bold transition-all border ${direction === 'FROM_CAMPUS' ? 'bg-bahria-blue text-white border-bahria-blue' : 'bg-gray-50 text-gray-500 border-transparent'}`}
                >
                  From Campus
                </button>
              </div>
           </div>

           <div className="flex gap-4">
             <div className="flex-1 space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wide ml-1">Time</label>
                <input 
                  type="time" 
                  className="w-full bg-gray-50 border-none rounded-xl p-4 font-bold text-gray-800 outline-none focus:ring-2 focus:ring-bahria-blue"
                  defaultValue="08:00"
                  onChange={(e) => {
                     // Convert 24h to AM/PM manually or just store raw for now. 
                     // Simple mock conversion for display consistency:
                     const [h, m] = e.target.value.split(':');
                     const hour = parseInt(h);
                     const ampm = hour >= 12 ? 'PM' : 'AM';
                     const h12 = hour % 12 || 12;
                     setTime(`${h12}:${m} ${ampm}`);
                  }}
                />
             </div>
             <div className="flex-1 space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wide ml-1">Seats</label>
                <input 
                  type="number" 
                  min={1} 
                  max={10}
                  value={capacity}
                  onChange={(e) => setCapacity(parseInt(e.target.value))}
                  className="w-full bg-gray-50 border-none rounded-xl p-4 font-bold text-gray-800 outline-none focus:ring-2 focus:ring-bahria-blue"
                />
             </div>
           </div>

           <div className="pt-4 flex gap-3">
             <Button type="button" variant="ghost" fullWidth onClick={onCancel}>Cancel</Button>
             <Button type="submit" fullWidth>Create Ride</Button>
           </div>
        </form>
      </main>
    </div>
  );
};

// --- Active Ride Dashboard ---
const ActiveRideDashboard: React.FC<{
  user: User;
  ride: Ride;
  allUsers: User[];
  onLeave: () => void;
  onStatusChange: (status: RideStatus) => void;
  onSendMessage: (text: string) => void;
  onBroadcastAlert: (text: string, type: Alert['type']) => void;
  onUpdateStatus: (status: PassengerStatus) => void;
  onDriverUpdatePassengerStatus: (pId: string, status: PassengerStatus) => void;
  onSubmitRating: (targetId: string, rating: number, comment: string) => void;
  onCancelBooking: (reason: string) => void;
  onMenuClick: () => void;
}> = ({ 
  user, ride, allUsers, onLeave, onStatusChange, onSendMessage, onBroadcastAlert,
  onUpdateStatus, onDriverUpdatePassengerStatus, onSubmitRating, onCancelBooking, onMenuClick
}) => {
  const isDriver = user.role === 'DRIVER';
  const route = ROUTES.find(r => r.id === ride.routeId);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [ratingTarget, setRatingTarget] = useState<User | null>(null);

  // For driver controls
  const handleNextStatus = () => {
    if (ride.status === 'SCHEDULED') onStatusChange('IN_PROGRESS');
    else if (ride.status === 'IN_PROGRESS') onStatusChange('COMPLETED');
  };

  return (
    <div className="min-h-full bg-truck-cream pb-32 animate-fade-in relative">
      {/* Map Section */}
      <div className="h-[350px] relative">
         <RideMap route={route?.points || []} currentStep={ride.currentLocationIndex} />
         
         <div className="absolute top-4 left-4 right-4 flex justify-between items-start z-10 pointer-events-none">
            <button onClick={onLeave} className="pointer-events-auto bg-white/90 backdrop-blur-md px-4 py-2.5 rounded-full shadow-lg text-bahria-blue hover:bg-white flex items-center gap-2 transition-all active:scale-95 font-bold text-sm">
               <ArrowLeft size={18} />
               Back
            </button>
            <div className="pointer-events-auto bg-white rounded-full shadow-lg">
               <HamburgerButton onClick={onMenuClick} />
            </div>
         </div>
      </div>

      {/* Sheet Content */}
      <div className="-mt-8 relative z-20 bg-truck-cream rounded-t-[40px] px-6 pt-8 pb-32 shadow-[0_-10px_40px_rgba(0,0,0,0.1)]">
         {/* Handle Bar */}
         <div className="w-12 h-1.5 bg-gray-300 rounded-full mx-auto mb-6"></div>

         <div className="mb-4">
            <Button variant="outline" fullWidth onClick={onLeave} className="border-gray-300 text-gray-500 bg-white/50 hover:bg-white hover:text-bahria-blue hover:border-bahria-blue transition-all py-3">
              <LayoutDashboard size={16} className="mr-2" />
              Minimize to Dashboard
            </Button>
         </div>

         {/* Header Info */}
         <div className="flex justify-between items-center mb-6">
            <div>
               <h2 className="text-2xl font-extrabold text-gray-900">{route?.name}</h2>
               <p className="text-gray-500 font-medium text-sm flex items-center gap-1">
                 <Clock size={14} /> {ride.startTime} • {ride.vehicleName}
               </p>
            </div>
            <div className={`px-4 py-2 rounded-xl font-bold text-xs uppercase tracking-wide ${ride.status === 'IN_PROGRESS' ? 'bg-green-100 text-green-700 animate-pulse' : 'bg-blue-100 text-blue-700'}`}>
               {ride.status.replace('_', ' ')}
            </div>
         </div>

         {/* Driver Controls or Passenger Actions */}
         {isDriver ? (
           <div className="mb-8">
              <div className="bg-white p-4 rounded-2xl shadow-soft border border-white/50">
                 <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wide mb-3">Captain Controls</h3>
                 <div className="grid grid-cols-2 gap-3">
                    <Button 
                      onClick={handleNextStatus}
                      disabled={ride.status === 'COMPLETED'}
                      className={ride.status === 'IN_PROGRESS' ? 'bg-red-500 hover:bg-red-600 shadow-red-200' : ''}
                    >
                      {ride.status === 'SCHEDULED' ? 'Start Ride' : ride.status === 'IN_PROGRESS' ? 'End Ride' : 'Completed'}
                    </Button>
                    <Button variant="outline" onClick={() => onBroadcastAlert("Traffic Jam ahead!", "DELAY")}>
                      <Megaphone size={18} className="mr-2" /> Alert
                    </Button>
                 </div>
              </div>
           </div>
         ) : (
           <div className="mb-8">
              <div className="bg-white p-4 rounded-2xl shadow-soft border border-white/50 flex justify-between items-center">
                 <div>
                    <p className="text-xs font-bold text-gray-400 uppercase">My Status</p>
                    <div className="flex gap-2 mt-2">
                       {['PENDING', 'COMING', 'PRESENT'].map((s: any) => {
                          const myStatus = ride.passengers.find(p => p.id === user.id)?.status;
                          const active = myStatus === s;
                          return (
                            <button
                              key={s}
                              onClick={() => onUpdateStatus(s)}
                              disabled={ride.status === 'COMPLETED'}
                              className={`p-2 rounded-lg transition-all ${active ? 'bg-bahria-blue text-white shadow-lg' : 'bg-gray-100 text-gray-400 hover:bg-gray-200'}`}
                            >
                               {s === 'PENDING' ? <Clock size={16} /> : s === 'COMING' ? <Navigation size={16} /> : <CheckCircle2 size={16} />}
                            </button>
                          );
                       })}
                    </div>
                 </div>
                 <button 
                   onClick={() => setShowCancelModal(true)} 
                   className="bg-red-50 text-red-500 p-3 rounded-xl hover:bg-red-100 transition-colors"
                 >
                    <UserX size={20} />
                 </button>
              </div>
           </div>
         )}

         {/* Passenger List */}
         <div>
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center justify-between">
              Passengers 
              <span className="text-sm font-medium text-gray-400">{ride.passengers.length}/{ride.capacity}</span>
            </h3>
            
            <div className="space-y-3">
               {ride.passengers.map((p) => (
                 <div key={p.id} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-50 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                       <img src={p.avatar} className="w-10 h-10 rounded-full bg-gray-200" />
                       <div>
                          <p className="font-bold text-gray-900 text-sm">{p.name}</p>
                          <p className="text-xs text-gray-500">{p.pickupLocation}</p>
                       </div>
                    </div>
                    {isDriver ? (
                       <select 
                         value={p.status}
                         onChange={(e) => onDriverUpdatePassengerStatus(p.id, e.target.value as PassengerStatus)}
                         className="text-xs font-bold bg-gray-100 border-none rounded-lg p-2 outline-none focus:ring-1 focus:ring-bahria-blue"
                       >
                         {Object.keys(STATUS_LABELS).map(k => <option key={k} value={k}>{STATUS_LABELS[k as keyof typeof STATUS_LABELS]}</option>)}
                       </select>
                    ) : (
                       <StatusBadge status={p.status} />
                    )}
                 </div>
               ))}
               {ride.passengers.length === 0 && (
                 <p className="text-center text-gray-400 text-sm py-4">No passengers yet.</p>
               )}
            </div>
         </div>
      </div>

      <RideAssistant ride={ride} />
      <RideGroupChat currentUser={user} messages={ride.chatMessages} onSendMessage={onSendMessage} />
      
      <CancellationModal 
        isOpen={showCancelModal} 
        onClose={() => setShowCancelModal(false)} 
        onConfirm={onCancelBooking} 
      />
      
      {ratingTarget && (
        <RatingModal 
          currentUser={user} 
          targetUser={ratingTarget} 
          ride={ride} 
          onSubmit={(rating, comment) => {
             onSubmitRating(ratingTarget.id, rating, comment);
             setRatingTarget(null);
          }} 
        />
      )}
    </div>
  );
};

// --- Main Application ---
const App: React.FC = () => {
  // Initialize Users from LocalStorage
  const [users, setUsers] = useState<User[]>(() => {
    try {
      const saved = localStorage.getItem('vroomly_users');
      return saved ? JSON.parse(saved) : MOCK_USERS;
    } catch (e) {
      console.error('Failed to parse users', e);
      return MOCK_USERS;
    }
  });

  // Initialize Rides from LocalStorage
  const [rides, setRides] = useState<Ride[]>(() => {
    try {
      const saved = localStorage.getItem('vroomly_rides');
      return saved ? JSON.parse(saved) : MOCK_RIDES;
    } catch (e) {
      console.error('Failed to parse rides', e);
      return MOCK_RIDES;
    }
  });

  // Initialize Current Session from LocalStorage
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('vroomly_current_user');
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });

  // Initialize Settings from LocalStorage
  const [appSettings, setAppSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('vroomly_settings');
      return saved ? JSON.parse(saved) : { notifications: true, language: 'English', twoFactorAuth: false };
    } catch {
      return { notifications: true, language: 'English', twoFactorAuth: false };
    }
  });

  // Persist Users
  useEffect(() => {
    localStorage.setItem('vroomly_users', JSON.stringify(users));
  }, [users]);

  // Persist Rides
  useEffect(() => {
    localStorage.setItem('vroomly_rides', JSON.stringify(rides));
  }, [rides]);

  // Persist Session
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('vroomly_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('vroomly_current_user');
    }
  }, [currentUser]);

  // Persist Settings
  useEffect(() => {
    localStorage.setItem('vroomly_settings', JSON.stringify(appSettings));
  }, [appSettings]);

  const [activeRideId, setActiveRideId] = useState<string | null>(null);
  const [authError, setAuthError] = useState('');
  
  // Navigation State
  const [currentView, setCurrentView] = useState<ViewType>('HOME');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const activeRide = rides.find(r => r.id === activeRideId);
  const usersCurrentBooking = currentUser?.role === 'PASSENGER' 
    ? rides.find(r => r.status !== 'COMPLETED' && r.passengers.some(p => p.id === currentUser.id))
    : null;

  const handleUpdateSettings = (newSettings: Partial<AppSettings>) => {
    setAppSettings(prev => ({ ...prev, ...newSettings }));
  };

  const handleLogin = (email: string, pass: string, role: UserRole) => {
    const user = users.find(u => u.email === email && u.password === pass);
    if (user) {
      if (user.role === role) {
        setCurrentUser(user);
        setAuthError('');
        setCurrentView('HOME');
      } else {
        setAuthError(`Email found, but not as a ${role === 'DRIVER' ? 'Driver' : 'Student'}. Please check your role.`);
      }
    } else {
      setAuthError('Invalid email or password');
    }
  };

  const handleSignup = (name: string, email: string, pass: string, role: UserRole): boolean => {
     if (users.find(u => u.email === email)) {
       setAuthError('Email already registered');
       return false;
     }
     const newUser: User = {
       id: `u${Date.now()}`,
       name, email, password: pass, role,
       avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${name}`,
       averageRating: 5.0,
       totalReviews: 0,
       totalRides: 0, // Initialized with 0 rides
       phone: '', // Initialized as empty per requirement
       isPremium: false
     };
     setUsers([...users, newUser]);
     setAuthError('');
     // Note: We do NOT log them in automatically. 
     // The user is saved to localStorage via the useEffect on 'users'.
     return true;
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setActiveRideId(null);
    setCurrentView('HOME');
    setIsMenuOpen(false);
  };

  const handleProfileUpdate = (updatedData: Partial<User>) => {
    if (!currentUser) return;
    const updatedUser = { ...currentUser, ...updatedData };
    
    // Update active session
    setCurrentUser(updatedUser);
    
    // Update user in main list
    setUsers(prevUsers => prevUsers.map(u => u.id === currentUser.id ? updatedUser : u));
    
    // Update all historical ride data where this user appears
    setRides(prevRides => prevRides.map(ride => ({
      ...ride,
      passengers: ride.passengers.map(p => p.id === currentUser.id ? { ...p, ...updatedData } : p)
    })));
  };

  const handleCreateRide = (rideData: Partial<Ride>) => {
    const newRide: Ride = { ...rideData as Ride, id: `ride_${Date.now()}` };
    setRides([...rides, newRide]);
    setCurrentView('HOME'); 
  };

  const handleJoinRide = (rideId: string) => {
    if (!currentUser) return;
    const existingBooking = rides.find(r => r.status !== 'COMPLETED' && r.passengers.some(p => p.id === currentUser.id));
    if (existingBooking) {
      alert(`You are already booked on a ride. Cancel that first.`);
      return;
    }
    setRides(prev => prev.map(r => r.id === rideId ? { ...r, passengers: [...r.passengers, { ...currentUser, status: 'PENDING', pickupLocation: 'Requested Stop' }] } : r));
    setActiveRideId(rideId);
  };

  const handleLeaveRideView = () => setActiveRideId(null); 

  const handleCancelBooking = (reason: string) => {
    if (!currentUser || !activeRideId) return;
    const cancellationLog: Cancellation = {
      userId: currentUser.id,
      userName: currentUser.name,
      reason,
      timestamp: new Date().toISOString()
    };
    setRides(prev => prev.map(r => {
      if (r.id === activeRideId) {
        return {
          ...r,
          passengers: r.passengers.filter(p => p.id !== currentUser.id),
          cancellations: [...(r.cancellations || []), cancellationLog]
        };
      }
      return r;
    }));
    setActiveRideId(null);
  };

  const handleUpdateStatus = (status: PassengerStatus) => {
    if (!activeRideId || !currentUser) return;
    setRides(prev => prev.map(r => r.id === activeRideId ? { ...r, passengers: r.passengers.map(p => p.id === currentUser.id ? { ...p, status } : p) } : r));
  };

  const handleDriverUpdatePassengerStatus = (passengerId: string, status: PassengerStatus) => {
    if (!activeRideId) return;
    setRides(prev => prev.map(r => r.id === activeRideId ? { ...r, passengers: r.passengers.map(p => p.id === passengerId ? { ...p, status } : p) } : r));
  };

  const handleDriverStatusChange = (status: RideStatus) => {
    if (!activeRideId) return;
    setRides(prev => prev.map(r => r.id === activeRideId ? { 
      ...r, 
      status, 
      isActive: status !== 'COMPLETED',
      completedAt: status === 'COMPLETED' ? new Date().toISOString() : r.completedAt
    } : r));
  };

  const handleSendMessage = (text: string) => {
    if (!currentUser || !activeRideId) return;
    const msg: GroupMessage = { id: Date.now().toString(), senderId: currentUser.id, senderName: currentUser.name, text, timestamp: new Date().toISOString(), role: currentUser.role };
    setRides(prev => prev.map(r => r.id === activeRideId ? { ...r, chatMessages: [...r.chatMessages, msg] } : r));
  };

  const handleBroadcastAlert = (text: string, type: Alert['type']) => {
     if (!currentUser || !activeRideId) return;
     const newAlert: Alert = {
       id: Date.now().toString(),
       text,
       type,
       time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
     };
     // Add to alert state AND chat history
     const msg: GroupMessage = { 
       id: Date.now().toString(), 
       senderId: currentUser.id, 
       senderName: currentUser.name, 
       text: `📢 ALERT: ${text}`, 
       timestamp: new Date().toISOString(), 
       role: currentUser.role,
       isAlert: true
     };
     
     setRides(prev => prev.map(r => r.id === activeRideId ? { 
       ...r, 
       latestAlert: newAlert,
       chatMessages: [...r.chatMessages, msg] 
     } : r));
  };

  const handleMenuNavigate = (view: ViewType) => {
    setCurrentView(view);
    setActiveRideId(null); // Minimize the ride view when navigating
  };

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (activeRide?.status === 'IN_PROGRESS') {
      const route = ROUTES.find(r => r.id === activeRide.routeId);
      const limit = route ? route.points.length - 1 : 3;
      interval = setInterval(() => {
        setRides(prev => prev.map(r => (r.id === activeRide.id && r.currentLocationIndex < limit) ? { ...r, currentLocationIndex: r.currentLocationIndex + 1 } : r));
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [activeRide?.status, activeRide?.id]);

  if (!currentUser) return <AuthScreen onLogin={handleLogin} onSignup={handleSignup} error={authError} />;

  const renderContent = () => {
    if (activeRideId && activeRide) {
       return (
        <ActiveRideDashboard 
          user={currentUser} 
          ride={activeRide} 
          allUsers={users}
          onLeave={handleLeaveRideView}
          onStatusChange={handleDriverStatusChange}
          onSendMessage={handleSendMessage}
          onBroadcastAlert={handleBroadcastAlert}
          onUpdateStatus={handleUpdateStatus}
          onDriverUpdatePassengerStatus={handleDriverUpdatePassengerStatus}
          onSubmitRating={(t, r, c) => console.log(t, r, c)}
          onCancelBooking={handleCancelBooking}
          onMenuClick={() => setIsMenuOpen(true)}
        />
       );
    }

    if (currentView === 'COMPLAINTS') return <ComplaintsView onMenuClick={() => setIsMenuOpen(true)} user={currentUser} />;
    
    // Updated Premium View prop passing
    if (currentView === 'PREMIUM') return <PremiumView onMenuClick={() => setIsMenuOpen(true)} user={currentUser} onUpdateProfile={handleProfileUpdate} />;

    if (currentView === 'SETTINGS') return <SettingsView onMenuClick={() => setIsMenuOpen(true)} settings={appSettings} onUpdate={handleUpdateSettings} />;
    
    if (currentView === 'PROFILE') {
      const calculatedRideCount = currentUser ? rides.filter(r => 
        r.status === 'COMPLETED' && (r.driverId === currentUser.id || r.passengers.some(p => p.id === currentUser.id))
      ).length : 0;

      return (
        <UserProfileView 
          user={currentUser} 
          rideCount={calculatedRideCount + currentUser.totalRides} 
          onLogout={handleLogout} 
          onUpdateProfile={handleProfileUpdate} 
          onMenuClick={() => setIsMenuOpen(true)} 
        />
      );
    }

    if (currentView === 'HISTORY') return <RideHistoryView user={currentUser} rides={rides} onMenuClick={() => setIsMenuOpen(true)} />;
    
    if (currentUser.role === 'DRIVER') {
      if (currentView === 'CREATE_RIDE') {
        return <CreateRideScreen user={currentUser} onCreate={handleCreateRide} onCancel={() => setCurrentView('HOME')} onMenuClick={() => setIsMenuOpen(true)} />;
      }
      return (
        <DriverDashboard 
          user={currentUser} 
          activeRides={rides} 
          onCreateClick={() => setCurrentView('CREATE_RIDE')}
          onManageRide={(id) => setActiveRideId(id)}
          onNavigate={setCurrentView}
          onMenuClick={() => setIsMenuOpen(true)}
        />
      );
    } else {
      return (
        <RideBrowser 
          user={currentUser} 
          availableRides={rides} 
          allUsers={users}
          onJoinRide={handleJoinRide}
          currentRideId={usersCurrentBooking?.id}
          onReturnToRide={(id) => setActiveRideId(id)}
          onNavigate={setCurrentView}
          onMenuClick={() => setIsMenuOpen(true)}
        />
      );
    }
  };

  return (
    <div className="relative overflow-hidden w-full max-w-[480px] mx-auto h-[100dvh] bg-truck-cream shadow-2xl flex flex-col">
      <div className="flex-1 overflow-y-auto overflow-x-hidden scrollbar-hide">
         {renderContent()}
      </div>
      
      {!activeRideId && <BottomNav current={currentView} onChange={setCurrentView} isDriver={currentUser.role === 'DRIVER'} />}
      
      <HamburgerDrawer 
        isOpen={isMenuOpen} 
        onClose={() => setIsMenuOpen(false)} 
        user={currentUser} 
        onNavigate={handleMenuNavigate} 
        onLogout={handleLogout} 
      />
    </div>
  );
};

export default App;
