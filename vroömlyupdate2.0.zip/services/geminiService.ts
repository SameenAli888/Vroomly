import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getRideAssistantResponse = async (
  userMessage: string, 
  context: string
): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    
    const systemInstruction = `
      You are "Bahria Bot", a helpful university transport assistant for Bahria University students.
      You are polite, professional, and helpful. You know about campus timings, exam stress, and traffic in the city (Islamabad/Rawalpindi).
      
      Current Ride Context:
      ${context}

      Answer brief questions about the ride, ETA, or campus location.
      If asked about the driver, use the info provided.
      Keep answers short (under 50 words).
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: userMessage,
      config: {
        systemInstruction: systemInstruction,
      }
    });

    return response.text || "Sorry, the signal is weak near the Margallas! Try again?";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Oops, system offline. Please try again.";
  }
};