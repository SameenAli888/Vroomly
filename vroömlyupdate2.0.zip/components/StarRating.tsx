import React from 'react';
import { Star } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  size?: number;
  showCount?: boolean;
  count?: number;
}

export const StarRating: React.FC<StarRatingProps> = ({ 
  rating, 
  size = 14, 
  showCount = false, 
  count = 0 
}) => {
  return (
    <div className="flex items-center space-x-1">
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            size={size}
            className={`${
              star <= Math.round(rating)
                ? 'fill-truck-yellow text-truck-yellow'
                : 'fill-gray-200 text-gray-200'
            }`}
          />
        ))}
      </div>
      {showCount && (
        <span className="text-xs text-gray-500 ml-1">
          ({count})
        </span>
      )}
    </div>
  );
};