import React, { useState } from 'react';
import { Button } from './Button';
import { X, AlertCircle } from 'lucide-react';

interface CancellationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (reason: string) => void;
}

const PREDEFINED_REASONS = [
  'Changed plans',
  'Found alternative transport',
  'Vehicle/Ride timing issue',
  'Emergency',
  'Mistake booking'
];

export const CancellationModal: React.FC<CancellationModalProps> = ({ isOpen, onClose, onConfirm }) => {
  const [selectedReason, setSelectedReason] = useState<string>('');
  const [customReason, setCustomReason] = useState('');

  if (!isOpen) return null;

  const handleConfirm = () => {
    const finalReason = selectedReason === 'Other' ? customReason : selectedReason;
    if (finalReason.trim()) {
      onConfirm(finalReason);
      // Reset state
      setSelectedReason('');
      setCustomReason('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl relative overflow-hidden">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
            <AlertCircle className="text-red-500" size={20} /> Cancel Seat
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X size={20} />
          </button>
        </div>
        
        <p className="text-sm text-gray-500 mb-4">
          Please let us know why you are cancelling your seat.
        </p>

        <div className="space-y-2 mb-4">
          {PREDEFINED_REASONS.map((reason) => (
            <label key={reason} className="flex items-center gap-3 p-3 border border-gray-100 rounded-xl cursor-pointer hover:bg-gray-50 transition-colors">
              <input 
                type="radio" 
                name="cancelReason" 
                value={reason} 
                checked={selectedReason === reason}
                onChange={(e) => setSelectedReason(e.target.value)}
                className="w-4 h-4 text-bahria-blue border-gray-300 focus:ring-bahria-blue"
              />
              <span className="text-sm text-gray-700 font-medium">{reason}</span>
            </label>
          ))}
          
          <label className="flex items-center gap-3 p-3 border border-gray-100 rounded-xl cursor-pointer hover:bg-gray-50 transition-colors">
            <input 
              type="radio" 
              name="cancelReason" 
              value="Other" 
              checked={selectedReason === 'Other'}
              onChange={(e) => setSelectedReason(e.target.value)}
              className="w-4 h-4 text-bahria-blue border-gray-300 focus:ring-bahria-blue"
            />
            <span className="text-sm text-gray-700 font-medium">Other</span>
          </label>
        </div>

        {selectedReason === 'Other' && (
          <textarea
            className="w-full border border-gray-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-bahria-blue focus:border-transparent outline-none resize-none bg-gray-50 text-gray-900 mb-4"
            placeholder="Please specify reason..."
            rows={2}
            value={customReason}
            onChange={(e) => setCustomReason(e.target.value)}
          />
        )}

        <div className="flex gap-3">
          <Button variant="ghost" fullWidth onClick={onClose}>Keep Seat</Button>
          <Button 
            variant="danger" 
            fullWidth 
            onClick={handleConfirm}
            disabled={!selectedReason || (selectedReason === 'Other' && !customReason.trim())}
          >
            Confirm Cancel
          </Button>
        </div>
      </div>
    </div>
  );
};