import React, { useState } from 'react';
import { Button } from './Button';
import { UserRole } from '../types';
import { Car, Mail, Lock, User as UserIcon, Eye, EyeOff, GraduationCap, ArrowLeft, CheckCircle2, KeyRound } from 'lucide-react';

interface AuthScreenProps {
  onLogin: (email: string, pass: string, role: UserRole) => void;
  onSignup: (name: string, email: string, pass: string, role: UserRole) => boolean;
  error?: string;
}

// Custom Bus Logo Component - Flattened Top (Van Style)
const BusLogo = () => (
  <svg viewBox="0 0 200 140" className="w-64 h-64 animate-float drop-shadow-2xl">
    {/* Body Top (Cream) - Flattened Roof */}
    <path d="M20,80 L20,45 C20,25 30,22 50,22 L150,22 C170,22 180,25 180,45 L180,80 Z" fill="#FFF8E7" stroke="#374151" strokeWidth="4"/>
    
    {/* Windows */}
    <rect x="35" y="35" width="35" height="30" rx="4" fill="#D4F1F4" stroke="#374151" strokeWidth="3"/>
    <rect x="82.5" y="35" width="35" height="30" rx="4" fill="#D4F1F4" stroke="#374151" strokeWidth="3"/>
    <rect x="130" y="35" width="35" height="30" rx="4" fill="#D4F1F4" stroke="#374151" strokeWidth="3"/>
    
    {/* Stripe */}
    <rect x="20" y="75" width="160" height="10" fill="#FCD34D" opacity="0.9"/>

    {/* Body Bottom Left (Blue) */}
    <path d="M20,80 L100,80 L100,130 L40,130 C30,130 20,120 20,110 Z" fill="#AEE2FF" stroke="#374151" strokeWidth="4"/>
    
    {/* Body Bottom Right (Pink) */}
    <path d="M100,80 L180,80 L180,110 C180,120 170,130 160,130 L100,130 Z" fill="#FFC6C6" stroke="#374151" strokeWidth="4"/>
    
    {/* Logo Emblem */}
    <circle cx="100" cy="100" r="14" fill="white" stroke="#374151" strokeWidth="3"/>
    <path d="M100,90 L106,100 L100,110 L94,100 Z" fill="#374151"/>

    {/* Headlights/Taillights */}
    <circle cx="25" cy="95" r="5" fill="#EF4444" stroke="#374151" strokeWidth="2"/>
    <circle cx="175" cy="95" r="5" fill="#FCD34D" stroke="#374151" strokeWidth="2"/>

    {/* Wheels */}
    <circle cx="50" cy="130" r="14" fill="#374151" />
    <circle cx="50" cy="130" r="8" fill="#FCA5A5" />
    <circle cx="150" cy="130" r="14" fill="#374151" />
    <circle cx="150" cy="130" r="8" fill="#FCA5A5" />
  </svg>
);

type AuthView = 'LANDING' | 'LOGIN' | 'SIGNUP' | 'FORGOT';

export const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin, onSignup, error }) => {
  const [view, setView] = useState<AuthView>('LANDING');
  const [showPassword, setShowPassword] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  
  // Form State
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('PASSENGER');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (view === 'LOGIN') {
      onLogin(email, password, role);
    } else if (view === 'SIGNUP') {
      const success = onSignup(name, email, password, role);
      if (success) {
        setView('LOGIN');
        setSuccessMessage('Account created successfully! Please log in.');
        setPassword('');
      }
    } else if (view === 'FORGOT') {
      // Simulate password reset
      setTimeout(() => {
        setSuccessMessage(`Reset link sent to ${email}`);
        setView('LOGIN');
      }, 1500);
    }
  };

  const handleViewChange = (newView: AuthView) => {
    setView(newView);
    setSuccessMessage('');
    // Clear form when switching views if needed
    if (newView === 'LANDING') {
      setEmail('');
      setPassword('');
      setName('');
    }
  };

  const isFormView = view === 'LOGIN' || view === 'SIGNUP' || view === 'FORGOT';

  return (
    <div className="h-[100dvh] flex flex-col bg-truck-cream overflow-hidden transition-colors duration-500">
      
      {/* --- Top Section (Image/Logo) --- */}
      <div 
        className={`relative bg-bahria-blue rounded-b-[3.5rem] shadow-card flex flex-col items-center justify-center overflow-hidden transition-all duration-500 ease-in-out z-10 
        ${isFormView ? 'h-[25%] rounded-b-[2.5rem]' : 'h-[55%]'}`}
      >
        {/* Abstract Background Patterns */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
        <div className="absolute -top-20 -right-20 w-64 h-64 bg-bahria-gold rounded-full blur-3xl opacity-20 animate-pulse-soft"></div>
        <div className="absolute bottom-[-50px] left-[-50px] w-64 h-64 bg-truck-pink rounded-full blur-3xl opacity-20 animate-pulse-soft"></div>

        {/* Back Button for Form View */}
        {isFormView && (
          <button 
            onClick={() => handleViewChange('LANDING')}
            className="absolute top-6 left-6 text-white bg-white/10 p-2 rounded-full hover:bg-white/20 transition-all z-50 backdrop-blur-md"
          >
            <ArrowLeft size={24} />
          </button>
        )}

        <div className={`relative z-10 transition-all duration-500 ${isFormView ? 'scale-50 mt-4' : 'scale-100 mt-10'}`}>
          <BusLogo />
        </div>
      </div>

      {/* --- Bottom Section (Content) --- */}
      <div className="flex-1 flex flex-col relative z-20">
        
        {/* Landing View Content */}
        {!isFormView && (
          <div className="flex-1 flex flex-col items-center justify-between px-8 pt-6 pb-24 animate-fade-in">
            
            {/* Branding - Script Font */}
            <div className="text-center space-y-2 mt-4">
              <h1 className="text-6xl text-bahria-blue font-script drop-shadow-sm">
                Vroömly
              </h1>
              <p className="text-gray-500 font-medium tracking-wider text-sm uppercase">
                Smart Rides, Simple Lives
              </p>
            </div>

            {/* Action Buttons */}
            <div className="w-full space-y-4">
              {/* Login Button (Was Signup) */}
              <Button 
                fullWidth 
                size="lg" 
                onClick={() => handleViewChange('LOGIN')}
                className="bg-bahria-blue text-white shadow-xl shadow-bahria-blue/30 py-5 rounded-3xl text-lg hover:scale-[1.02] transition-transform"
              >
                Log In
              </Button>
            </div>
          </div>
        )}

        {/* Form View Content (Login/Signup/Forgot) */}
        {isFormView && (
          <div className="flex-1 overflow-y-auto px-8 pt-6 pb-4 animate-slide-up">
            <div className="text-center mb-6">
              <h2 className="text-3xl font-script text-bahria-blue mb-1">
                {view === 'LOGIN' ? 'Welcome Back' : view === 'SIGNUP' ? 'New Journey' : 'Reset Password'}
              </h2>
              <p className="text-sm text-gray-500">
                {view === 'LOGIN' ? 'Please sign in to continue' : view === 'SIGNUP' ? 'Create your account' : 'Enter email to reset password'}
              </p>
            </div>

            <form id="auth-form" onSubmit={handleSubmit} className="space-y-4">
              {/* Success Message Banner */}
              {successMessage && (
                <div className="bg-green-50 text-green-700 text-sm p-4 rounded-2xl flex items-center justify-center gap-2 border border-green-100 font-bold animate-fade-in mb-4">
                  <CheckCircle2 size={18} className="text-green-600" />
                  {successMessage}
                </div>
              )}

              {error && view !== 'FORGOT' && (
                <div className="bg-red-50 text-red-600 text-sm p-4 rounded-2xl text-center border border-red-100 font-medium animate-fade-in">
                  {error}
                </div>
              )}

              {/* Role Selection for Login and Signup */}
              {view !== 'FORGOT' && (
                 <div className="grid grid-cols-2 gap-3 mb-2">
                 <button
                   type="button"
                   onClick={() => setRole('PASSENGER')}
                   className={`p-3 rounded-2xl border-2 text-xs font-bold flex flex-col items-center justify-center gap-2 transition-all shadow-sm ${role === 'PASSENGER' ? 'border-bahria-blue bg-white text-bahria-blue ring-2 ring-bahria-blue/20' : 'border-transparent bg-white/50 text-gray-400'}`}
                 >
                   <GraduationCap size={20} />
                   Student
                 </button>
                 <button
                   type="button"
                   onClick={() => setRole('DRIVER')}
                   className={`p-3 rounded-2xl border-2 text-xs font-bold flex flex-col items-center justify-center gap-2 transition-all shadow-sm ${role === 'DRIVER' ? 'border-bahria-blue bg-white text-bahria-blue ring-2 ring-bahria-blue/20' : 'border-transparent bg-white/50 text-gray-400'}`}
                 >
                   <Car size={20} />
                   Driver
                 </button>
               </div>
              )}

              {view === 'SIGNUP' && (
                <div className="bg-white p-1 rounded-2xl shadow-sm border border-bahria-blue/5 animate-fade-in">
                  <div className="relative group">
                    <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                    <input 
                      type="text" 
                      placeholder="Full Name" 
                      required
                      className="w-full pl-12 pr-4 py-4 bg-transparent outline-none font-medium text-gray-900 placeholder:text-gray-400"
                      value={name}
                      onChange={e => setName(e.target.value)}
                    />
                  </div>
                </div>
              )}

              <div className="bg-white p-1 rounded-2xl shadow-sm border border-bahria-blue/5">
                <div className="relative group">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                  <input 
                    type="email" 
                    placeholder="University Email" 
                    required
                    className="w-full pl-12 pr-4 py-4 bg-transparent outline-none font-medium text-gray-900 placeholder:text-gray-400"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                  />
                </div>
              </div>

              {view !== 'FORGOT' && (
                <div className="bg-white p-1 rounded-2xl shadow-sm border border-bahria-blue/5 animate-fade-in">
                  <div className="relative group">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                    <input 
                      type={showPassword ? "text" : "password"} 
                      placeholder="Password" 
                      required
                      className="w-full pl-12 pr-12 py-4 bg-transparent outline-none font-medium text-gray-900 placeholder:text-gray-400"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-bahria-blue p-2"
                    >
                      {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>
                </div>
              )}

              {view === 'LOGIN' && (
                <div className="flex justify-end">
                  <button 
                    type="button" 
                    onClick={() => handleViewChange('FORGOT')}
                    className="text-xs font-bold text-gray-500 hover:text-bahria-blue transition-colors"
                  >
                    Forgot Password?
                  </button>
                </div>
              )}

              <Button 
                fullWidth 
                size="lg" 
                type="submit" 
                className="shadow-xl shadow-bahria-blue/20 text-lg py-5 rounded-3xl mt-6"
              >
                {view === 'LOGIN' ? 'Let\'s Go' : view === 'SIGNUP' ? 'Create Account' : 'Reset Password'}
              </Button>

              {/* Toggle Links */}
              <div className="text-center mt-6 pb-4">
                {view === 'FORGOT' ? (
                  <button 
                    type="button"
                    onClick={() => handleViewChange('LOGIN')}
                    className="font-bold text-gray-500 hover:text-bahria-blue transition-all text-sm"
                  >
                    Back to Login
                  </button>
                ) : (
                  <p className="text-gray-500 text-sm font-medium">
                    {view === 'LOGIN' ? "Don't have an account?" : "Already have an account?"}
                    <button 
                      type="button"
                      onClick={() => handleViewChange(view === 'LOGIN' ? 'SIGNUP' : 'LOGIN')}
                      className="ml-2 font-bold text-bahria-blue hover:underline transition-all"
                    >
                      {view === 'LOGIN' ? "Sign Up" : "Log In"}
                    </button>
                  </p>
                )}
              </div>

            </form>
          </div>
        )}
      </div>

    </div>
  );
};