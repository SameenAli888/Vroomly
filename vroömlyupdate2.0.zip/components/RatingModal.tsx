import React, { useState } from 'react';
import { User, Ride } from '../types';
import { Star, Check } from 'lucide-react';
import { Button } from './Button';

interface RatingModalProps {
  currentUser: User;
  ride: Ride;
  targetUser: User; // The person being rated (Driver for passenger, Passenger for driver)
  onSubmit: (rating: number, comment: string) => void;
}

export const RatingModal: React.FC<RatingModalProps> = ({
  currentUser,
  ride,
  targetUser,
  onSubmit
}) => {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    if (rating === 0) return;
    onSubmit(rating, comment);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
        <div className="bg-white rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl border-t-8 border-pak-green">
           <div className="w-16 h-16 bg-green-100 text-pak-green rounded-full flex items-center justify-center mx-auto mb-4">
             <Check size={32} />
           </div>
           <h2 className="text-2xl font-bold text-gray-900 mb-2">Shukriya!</h2>
           <p className="text-gray-500">Your feedback helps us keep the rides safe and fun.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl relative overflow-hidden">
        {/* Decor */}
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-truck-pink via-truck-yellow to-truck-teal"></div>

        <div className="text-center mb-6">
          <h2 className="text-xl font-bold text-gray-900">Ride Completed!</h2>
          <p className="text-sm text-gray-500 mt-1">How was your experience with</p>
          <div className="mt-4 flex flex-col items-center">
             <img src={targetUser.avatar} alt={targetUser.name} className="w-16 h-16 rounded-full border-4 border-white shadow-md" />
             <h3 className="font-bold text-lg mt-2">{targetUser.name}</h3>
             <span className="text-xs bg-gray-100 px-2 py-1 rounded text-gray-600">{targetUser.role === 'DRIVER' ? 'Captain' : 'Passenger'}</span>
          </div>
        </div>

        <div className="flex justify-center space-x-2 mb-6">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              onClick={() => setRating(star)}
              className="focus:outline-none transition-transform hover:scale-110 active:scale-95"
            >
              <Star
                size={32}
                className={`${
                  star <= rating 
                    ? 'fill-truck-yellow text-truck-yellow drop-shadow-sm' 
                    : 'fill-gray-100 text-gray-300'
                }`}
              />
            </button>
          ))}
        </div>

        <textarea
          className="w-full border border-gray-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-pak-green focus:border-transparent outline-none resize-none bg-gray-50 text-gray-900"
          placeholder="Write a short review (optional)..."
          rows={3}
          value={comment}
          onChange={(e) => setComment(e.target.value)}
        />

        <div className="mt-6">
          <Button 
            fullWidth 
            onClick={handleSubmit} 
            disabled={rating === 0}
            className={rating > 0 ? 'bg-gradient-to-r from-pak-green to-green-700' : ''}
          >
            Submit Review
          </Button>
        </div>
      </div>
    </div>
  );
};