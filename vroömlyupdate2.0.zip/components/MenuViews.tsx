
import React, { useState } from 'react';
import { HamburgerButton } from './HamburgerMenu';
import { AlertTriangle, Send, CheckCircle2, Crown, Star, Shield, Zap, CreditCard, Smartphone, Check, X, Armchair, VolumeX, Users, Lock } from 'lucide-react';
import { Button } from './Button';
import { User, Complaint } from '../types';

interface MenuViewProps {
  onMenuClick: () => void;
}

interface ComplaintsViewProps extends MenuViewProps {
  user: User | null;
}

// --- Complaints View ---
export const ComplaintsView: React.FC<ComplaintsViewProps> = ({ onMenuClick, user }) => {
  const [submitted, setSubmitted] = useState(false);
  const [category, setCategory] = useState('Behavior');
  const [details, setDetails] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Create new complaint object
    const newComplaint: Complaint = {
      id: `comp_${Date.now()}`,
      userId: user?.id || 'anonymous',
      userName: user?.name || 'Anonymous',
      category,
      details,
      timestamp: new Date().toISOString(),
      status: 'PENDING'
    };

    // Save to local storage
    try {
      const existingData = localStorage.getItem('vroomly_complaints');
      const complaints: Complaint[] = existingData ? JSON.parse(existingData) : [];
      complaints.push(newComplaint);
      localStorage.setItem('vroomly_complaints', JSON.stringify(complaints));
      console.log('Complaint saved to localStorage:', newComplaint);
    } catch (error) {
      console.error('Failed to save complaint:', error);
    }

    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="min-h-full bg-truck-cream flex flex-col animate-fade-in">
        <div className="pt-8 px-6 pb-6 flex justify-between items-start">
          <div>
            <h2 className="text-3xl font-extrabold text-bahria-blue">Support</h2>
          </div>
          <div className="bg-white rounded-full shadow-sm">
            <HamburgerButton onClick={onMenuClick} />
          </div>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
          <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6 shadow-lg shadow-green-100">
            <CheckCircle2 size={40} />
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Report Received</h3>
          <p className="text-gray-500 mb-8">
            Thank you for bringing this to our attention. Our safety team will review your report within 24 hours.
          </p>
          <Button onClick={() => { setSubmitted(false); setDetails(''); }} variant="outline">
            Submit Another
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-full bg-truck-cream pb-32 animate-fade-in">
      <div className="pt-8 px-6 pb-6 flex items-start justify-between">
        <div>
           <h2 className="text-3xl font-extrabold text-bahria-blue">Complaints</h2>
           <p className="text-gray-400 font-medium">We're here to help</p>
        </div>
        <div className="bg-white rounded-full shadow-sm">
           <HamburgerButton onClick={onMenuClick} />
        </div>
      </div>

      <main className="px-5 space-y-6">
        <div className="bg-white rounded-[32px] p-6 shadow-soft border border-white/50">
           <div className="flex items-start gap-4 mb-6">
              <div className="p-3 bg-red-50 text-red-500 rounded-2xl">
                <AlertTriangle size={24} />
              </div>
              <p className="text-sm text-gray-600 leading-relaxed mt-1">
                Please provide details about the incident. For emergencies, please call campus security directly.
              </p>
           </div>

           <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                 <label className="text-xs font-bold text-gray-400 uppercase tracking-wide ml-1">Issue Category</label>
                 <div className="grid grid-cols-2 gap-2">
                    {['Behavior', 'Timing', 'Vehicle', 'App Bug'].map(cat => (
                      <button 
                        key={cat}
                        type="button"
                        onClick={() => setCategory(cat)}
                        className={`py-3 rounded-xl text-xs font-bold transition-all border ${category === cat ? 'bg-bahria-blue text-white border-bahria-blue shadow-lg shadow-bahria-blue/20' : 'bg-gray-50 text-gray-500 border-transparent hover:bg-gray-100'}`}
                      >
                        {cat}
                      </button>
                    ))}
                 </div>
              </div>

              <div className="space-y-2">
                 <label className="text-xs font-bold text-gray-400 uppercase tracking-wide ml-1">Details</label>
                 <textarea 
                    required
                    value={details}
                    onChange={(e) => setDetails(e.target.value)}
                    rows={5}
                    placeholder="Describe what happened..."
                    className="w-full bg-gray-50 border-none rounded-2xl p-4 text-sm font-medium focus:ring-2 focus:ring-bahria-blue outline-none resize-none"
                 />
              </div>

              <Button type="submit" fullWidth className="py-4 rounded-2xl shadow-lg mt-2">
                <Send size={18} className="mr-2" /> Submit Report
              </Button>
           </form>
        </div>
      </main>
    </div>
  );
};

// --- Payment Modal Component ---
const PaymentModal: React.FC<{ 
  isOpen: boolean; 
  onClose: () => void; 
  onConfirm: () => void; 
  plan: { name: string; price: string };
}> = ({ isOpen, onClose, onConfirm, plan }) => {
  const [method, setMethod] = useState<'easypaisa' | 'jazzcash' | 'card'>('easypaisa');
  const [processing, setProcessing] = useState(false);

  if (!isOpen) return null;

  const handlePay = () => {
    setProcessing(true);
    setTimeout(() => {
      setProcessing(false);
      onConfirm();
    }, 2000); // Simulate network delay
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
       <div className="bg-white w-full max-w-sm rounded-[32px] p-6 shadow-2xl animate-slide-up relative">
          <button onClick={onClose} className="absolute top-4 right-4 bg-gray-100 p-2 rounded-full hover:bg-gray-200"><X size={20} /></button>
          
          <div className="mb-6">
             <h3 className="text-xl font-bold text-gray-900">Secure Payment</h3>
             <p className="text-sm text-gray-500">Subscribe to {plan.name}</p>
          </div>

          <div className="bg-blue-50 p-4 rounded-2xl mb-6 flex justify-between items-center border border-blue-100">
             <span className="font-bold text-bahria-blue">Total Amount</span>
             <span className="font-extrabold text-xl text-bahria-blue">{plan.price}</span>
          </div>

          <div className="space-y-3 mb-8">
             <label className="text-xs font-bold text-gray-400 uppercase tracking-wide ml-1">Select Method</label>
             {[
               { id: 'easypaisa', label: 'EasyPaisa', icon: Smartphone, color: 'text-green-600 bg-green-100' },
               { id: 'jazzcash', label: 'JazzCash', icon: Smartphone, color: 'text-red-600 bg-red-100' },
               { id: 'card', label: 'Credit/Debit Card', icon: CreditCard, color: 'text-blue-600 bg-blue-100' },
             ].map((m) => (
               <button
                 key={m.id}
                 onClick={() => setMethod(m.id as any)}
                 className={`w-full flex items-center gap-3 p-4 rounded-xl border transition-all ${method === m.id ? 'border-bahria-blue bg-blue-50/50 ring-1 ring-bahria-blue' : 'border-gray-200 hover:bg-gray-50'}`}
               >
                  <div className={`p-2 rounded-lg ${m.color}`}><m.icon size={18} /></div>
                  <span className="font-bold text-gray-700">{m.label}</span>
                  {method === m.id && <CheckCircle2 size={18} className="ml-auto text-bahria-blue" />}
               </button>
             ))}
          </div>

          <Button 
            fullWidth 
            onClick={handlePay} 
            disabled={processing}
            className={`py-4 rounded-2xl text-lg shadow-lg ${processing ? 'opacity-80' : ''}`}
          >
             {processing ? (
               <div className="flex items-center gap-2">
                 <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                 Processing...
               </div>
             ) : (
               'Pay Now'
             )}
          </Button>
       </div>
    </div>
  );
};

interface PremiumViewProps extends MenuViewProps {
  user: User | null;
  onUpdateProfile: (data: Partial<User>) => void;
}

// --- Premium View ---
export const PremiumView: React.FC<PremiumViewProps> = ({ onMenuClick, user, onUpdateProfile }) => {
  const [showPayment, setShowPayment] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<{name: string, price: string, duration: 'week' | 'month'}>({ 
    name: 'Semester Pass', 
    price: 'PKR 4,500', 
    duration: 'month' 
  });

  const handleStartPlan = (planName: string, price: string, duration: 'week' | 'month') => {
    setSelectedPlan({ name: planName, price, duration });
    setShowPayment(true);
  };

  const handlePaymentSuccess = () => {
    setShowPayment(false);
    
    // Calculate expiration date
    const date = new Date();
    if (selectedPlan.duration === 'month') {
        date.setMonth(date.getMonth() + 1);
    } else {
        date.setDate(date.getDate() + 7);
    }
    const expiryString = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

    onUpdateProfile({ 
      isPremium: true,
      premiumExpiry: expiryString,
      preferences: {
        frontSeat: false,
        quietRide: false,
        genderFilter: false
      }
    });
  };

  const togglePreference = (key: keyof NonNullable<User['preferences']>) => {
    if (!user || !user.preferences) return;
    onUpdateProfile({
      preferences: {
        ...user.preferences,
        [key]: !user.preferences[key]
      }
    });
  };

  if (user?.isPremium) {
    return (
      <div className="min-h-full bg-bahria-blue text-white pb-32 animate-fade-in relative overflow-hidden">
        {/* Active Premium Background */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-b from-bahria-gold to-transparent rounded-full blur-[80px] opacity-30 translate-x-1/3 -translate-y-1/3 animate-pulse-soft"></div>
        
        <div className="pt-8 px-6 pb-6 flex items-start justify-between relative z-10">
          <div>
             <div className="flex items-center gap-2 mb-1">
               <Crown size={24} className="text-bahria-gold fill-bahria-gold" />
               <span className="text-xs font-bold text-bahria-gold uppercase tracking-widest">Active Member</span>
             </div>
             <h2 className="text-3xl font-extrabold">Vroömly<span className="text-bahria-gold">+</span></h2>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-full">
             <HamburgerButton onClick={onMenuClick} />
          </div>
        </div>

        <main className="px-5 space-y-6 relative z-10">
           {/* Status Card */}
           <div className="bg-gradient-to-br from-bahria-gold/20 to-white/5 backdrop-blur-xl border border-bahria-gold/30 rounded-[32px] p-6">
              <div className="flex items-center justify-between mb-4">
                 <h3 className="font-bold text-lg">Your Subscription</h3>
                 <span className="bg-green-500/20 text-green-300 text-[10px] font-bold px-2 py-1 rounded-full border border-green-500/30">ACTIVE</span>
              </div>
              <p className="text-blue-100 text-sm mb-4">You have full access to all Vroömly+ features until <span className="text-white font-bold">{user.premiumExpiry || 'Lifetime'}</span>.</p>
              <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                <div className="h-full w-3/4 bg-bahria-gold rounded-full shadow-[0_0_10px_#D4AF37]"></div>
              </div>
           </div>

           {/* Smart Preferences Control */}
           <div>
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                <Zap size={20} className="text-bahria-gold" /> Smart Preferences
              </h3>
              
              <div className="space-y-3">
                 {[
                   { key: 'frontSeat', label: 'Front Seat Priority', icon: Armchair, desc: 'Request front seat when booking' },
                   { key: 'quietRide', label: 'Quiet Ride Mode', icon: VolumeX, desc: 'Signal preference for minimal chat' },
                   { key: 'genderFilter', label: 'Same Gender Only', icon: Users, desc: 'Only see rides from same gender' },
                 ].map((pref) => {
                   const isActive = user.preferences?.[pref.key as keyof typeof user.preferences];
                   return (
                     <button
                       key={pref.key}
                       onClick={() => togglePreference(pref.key as any)}
                       className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-all ${isActive ? 'bg-white text-bahria-blue border-white' : 'bg-white/5 text-gray-300 border-white/10 hover:bg-white/10'}`}
                     >
                       <div className="flex items-center gap-4 text-left">
                         <div className={`p-2.5 rounded-xl ${isActive ? 'bg-bahria-blue/10 text-bahria-blue' : 'bg-white/10 text-gray-400'}`}>
                           <pref.icon size={20} />
                         </div>
                         <div>
                           <div className="font-bold text-sm">{pref.label}</div>
                           <div className={`text-[10px] ${isActive ? 'text-gray-500' : 'text-gray-500'}`}>{pref.desc}</div>
                         </div>
                       </div>
                       <div className={`w-10 h-6 rounded-full p-1 transition-colors ${isActive ? 'bg-bahria-blue' : 'bg-gray-600'}`}>
                         <div className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${isActive ? 'translate-x-4' : ''}`} />
                       </div>
                     </button>
                   );
                 })}
              </div>
           </div>
        </main>
      </div>
    );
  }

  // --- NON-PREMIUM VIEW ---
  return (
    <div className="min-h-full bg-bahria-blue text-white pb-32 animate-fade-in relative overflow-hidden">
      <PaymentModal 
        isOpen={showPayment} 
        onClose={() => setShowPayment(false)} 
        onConfirm={handlePaymentSuccess}
        plan={selectedPlan}
      />

      {/* Background FX */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-bahria-gold rounded-full blur-[100px] opacity-20 translate-x-1/3 -translate-y-1/3"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-truck-pink rounded-full blur-[80px] opacity-20 -translate-x-1/3 translate-y-1/3"></div>

      <div className="pt-8 px-6 pb-6 flex items-start justify-between relative z-10">
        <div>
           <div className="flex items-center gap-2 mb-1">
             <Crown size={24} className="text-bahria-gold animate-bounce" />
             <span className="text-xs font-bold text-bahria-gold uppercase tracking-widest">Premium</span>
           </div>
           <h2 className="text-3xl font-extrabold">Vroömly<span className="text-bahria-gold">+</span></h2>
        </div>
        <div className="bg-white/10 backdrop-blur-md rounded-full">
           <HamburgerButton onClick={onMenuClick} />
        </div>
      </div>

      <main className="px-5 space-y-6 relative z-10">
         
         {/* Feature Showcase List (Shown First) */}
         <div className="space-y-2">
            <h3 className="font-bold text-lg mb-2 pl-1">Unlock Premium Features</h3>
            <div className="bg-white/10 backdrop-blur-md rounded-[28px] p-2 border border-white/10">
                {[
                    { label: 'Front Seat Priority', icon: Armchair, desc: 'Reserve the front seat automatically' },
                    { label: 'Quiet Ride Mode', icon: VolumeX, desc: 'Signal you prefer a silent trip' },
                    { label: 'Gender Filter', icon: Users, desc: 'See rides from specific gender only' },
                    { label: 'Priority Support', icon: Star, desc: 'Direct line to support team' },
                ].map((item, i) => (
                    <div key={i} className="flex items-center justify-between p-3.5 rounded-2xl border border-transparent hover:bg-white/5 hover:border-white/5 transition-all group">
                        <div className="flex items-center gap-4">
                            <div className="bg-gradient-to-br from-bahria-gold to-amber-600 text-white p-2.5 rounded-xl shadow-lg shadow-amber-900/20 group-hover:scale-110 transition-transform">
                                <item.icon size={18} />
                            </div>
                            <div>
                                <h4 className="font-bold text-sm">{item.label}</h4>
                                <p className="text-xs text-blue-200 opacity-80">{item.desc}</p>
                            </div>
                        </div>
                        <Lock size={16} className="text-white/30" />
                    </div>
                ))}
            </div>
         </div>

         {/* Plan Cards (Shown Second) */}
         <div>
            <h3 className="font-bold text-lg mb-3 pl-1">Choose a Plan</h3>
            <div className="space-y-4">
                <div 
                  onClick={() => handleStartPlan('Semester Pass', 'PKR 4,500', 'month')}
                  className="bg-white text-bahria-blue rounded-[32px] p-6 shadow-float relative overflow-hidden group hover:scale-[1.02] transition-transform cursor-pointer border-4 border-bahria-gold"
                >
                   <div className="absolute top-0 right-0 bg-bahria-gold text-bahria-blue text-xs font-bold px-3 py-1 rounded-bl-xl">POPULAR</div>
                   <h4 className="font-bold text-lg">Semester Pass</h4>
                   <div className="flex items-baseline gap-1 mt-1 mb-4">
                      <span className="text-3xl font-extrabold">PKR 4,500</span>
                      <span className="text-gray-500 font-medium text-xs">/ month</span>
                   </div>
                   <Button fullWidth className="bg-bahria-blue text-white hover:bg-bahria-blue-light">Get Started</Button>
                </div>

                <div 
                  onClick={() => handleStartPlan('Weekly Pass', 'PKR 1,200', 'week')}
                  className="bg-white/5 text-white border border-white/10 rounded-[32px] p-6 shadow-sm hover:bg-white/10 transition-colors cursor-pointer"
                >
                   <h4 className="font-bold text-lg">Weekly Pass</h4>
                   <div className="flex items-baseline gap-1 mt-1 mb-4">
                      <span className="text-3xl font-extrabold">PKR 1,200</span>
                      <span className="text-blue-200 font-medium text-xs">/ week</span>
                   </div>
                   <Button fullWidth variant="outline" className="text-white border-white/30 hover:bg-white/10">Select Plan</Button>
                </div>
            </div>
         </div>
         
         <p className="text-center text-xs text-blue-200 opacity-60 pb-6">
           Cancel anytime. Terms & conditions apply.
         </p>
      </main>
    </div>
  );
};
