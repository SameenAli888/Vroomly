import React from 'react';
import { PassengerStatus } from '../types';
import { CheckCircle2, Clock, MapPinOff, UserX } from 'lucide-react';

interface StatusBadgeProps {
  status: PassengerStatus;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const styles = {
    PENDING: 'bg-gray-100 text-gray-600 border-gray-200',
    COMING: 'bg-amber-50 text-amber-700 border-amber-200',
    PRESENT: 'bg-indigo-50 text-bahria-blue border-indigo-200',
    ABSENT: 'bg-red-50 text-red-600 border-red-200'
  };

  const labels = {
    PENDING: 'Waiting',
    COMING: 'En Route',
    PRESENT: 'Onboard',
    ABSENT: 'Absent'
  };

  const iconMap = {
    PENDING: <Clock className="w-3 h-3 mr-1.5" />,
    COMING: <Clock className="w-3 h-3 mr-1.5" />,
    PRESENT: <CheckCircle2 className="w-3 h-3 mr-1.5" />,
    ABSENT: <UserX className="w-3 h-3 mr-1.5" />
  };

  return (
    <span className={`inline-flex items-center px-3 py-1 rounded-full text-[10px] uppercase tracking-wider font-bold border ${styles[status]} transition-colors`}>
      {iconMap[status]}
      {labels[status]}
    </span>
  );
};