
import React from 'react';
import { Menu, X, LayoutDashboard, Map, AlertTriangle, User as UserIcon, Crown, Settings, LogOut, ChevronRight } from 'lucide-react';
import { User } from '../types';

interface HamburgerButtonProps {
  onClick: () => void;
}

export const HamburgerButton: React.FC<HamburgerButtonProps> = ({ onClick }) => (
  <button 
    onClick={onClick} 
    className="p-2.5 rounded-full hover:bg-black/5 active:scale-95 transition-all text-gray-800 relative z-50"
  >
    <Menu size={24} strokeWidth={2.5} />
  </button>
);

interface HamburgerDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  onNavigate: (view: any) => void;
  onLogout: () => void;
}

export const HamburgerDrawer: React.FC<HamburgerDrawerProps> = ({ isOpen, onClose, user, onNavigate, onLogout }) => {
  const handleNav = (view: string) => {
    onNavigate(view);
    onClose();
  };

  const menuItems = [
    { label: 'Dashboard', icon: LayoutDashboard, view: 'HOME' },
    { label: 'Select Route', icon: Map, view: 'HOME' }, // Maps to Home where route selection happens
    { label: 'Complaints', icon: AlertTriangle, view: 'COMPLAINTS' },
    { label: 'Profile', icon: UserIcon, view: 'PROFILE' },
    { label: 'Premium', icon: Crown, view: 'PREMIUM' },
    { label: 'Settings', icon: Settings, view: 'SETTINGS' },
  ];

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div 
          className="absolute inset-0 bg-black/40 backdrop-blur-sm z-[998] animate-fade-in"
          onClick={onClose}
        />
      )}

      {/* Drawer */}
      <div 
        className={`absolute top-0 left-0 bottom-0 w-[300px] bg-truck-cream z-[999] shadow-2xl transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="h-full flex flex-col bg-truck-cream">
          {/* Header */}
          <div className="p-6 pt-12 bg-bahria-blue text-white rounded-br-[50px] shadow-lg relative overflow-hidden shrink-0">
             <div className="absolute top-0 right-0 w-32 h-32 bg-bahria-gold rounded-full blur-2xl opacity-20 translate-x-1/3 -translate-y-1/3"></div>
             
             <button 
                onClick={onClose}
                className="absolute top-4 right-4 bg-white/10 p-2 rounded-full hover:bg-white/20 text-white transition-colors"
             >
               <X size={20} />
             </button>

             <div className="flex items-center gap-4 relative z-10 mt-2">
               <div className="relative">
                 {/* Premium Glow & Border */}
                 {user.isPremium && <div className="absolute inset-0 bg-bahria-gold blur-md rounded-full"></div>}
                 <img 
                   src={user.avatar} 
                   alt={user.name} 
                   className={`relative w-16 h-16 rounded-full shadow-lg bg-gray-100 object-cover ${user.isPremium ? 'border-4 border-bahria-gold' : 'border-4 border-white/10'}`} 
                 />
                 {user.isPremium && (
                   <div className="absolute -bottom-1 -right-1 bg-bahria-gold text-bahria-blue p-1 rounded-full border-2 border-bahria-blue">
                     <Crown size={10} fill="currentColor" />
                   </div>
                 )}
               </div>
               
               <div className="min-w-0">
                 <h3 className="font-bold text-xl truncate tracking-tight">{user.name}</h3>
                 <div className="flex items-center gap-2 mt-1">
                   <span className="text-[10px] font-bold bg-bahria-gold text-bahria-blue px-2 py-0.5 rounded-full uppercase tracking-wider">
                     {user.role === 'DRIVER' ? 'Captain' : 'Student'}
                   </span>
                   {user.isPremium && (
                     <span className="text-[10px] font-bold bg-white/20 text-white px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1">
                       PRO
                     </span>
                   )}
                 </div>
               </div>
             </div>
          </div>

          {/* Menu Items */}
          <div className="flex-1 py-6 px-4 overflow-y-auto space-y-1">
             {menuItems.map((item, index) => (
               <button 
                 key={index}
                 onClick={() => handleNav(item.view)}
                 className="w-full flex items-center justify-between p-4 rounded-2xl hover:bg-white/50 text-gray-600 font-bold transition-all group active:scale-[0.98]"
               >
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors shadow-sm border border-gray-100
                      ${item.label === 'Premium' ? 'bg-amber-50 text-amber-500' : 'bg-white text-gray-400 group-hover:text-bahria-blue group-hover:border-bahria-blue/20'}`}
                    >
                      <item.icon size={20} />
                    </div>
                    <span className="text-sm group-hover:text-bahria-blue transition-colors">{item.label}</span>
                  </div>
                  <ChevronRight size={16} className="text-gray-300 group-hover:text-bahria-blue transition-colors" />
               </button>
             ))}
          </div>

          {/* Footer - Logout */}
          <div className="p-6 border-t border-gray-100 bg-white/30">
            <button 
              onClick={onLogout}
              className="w-full flex items-center justify-center gap-2 bg-red-50 text-red-500 font-bold py-4 rounded-2xl hover:bg-red-100 transition-colors active:scale-95 shadow-sm border border-red-100"
            >
              <LogOut size={20} />
              Log Out
            </button>
            <p className="text-center text-[10px] text-gray-400 mt-4 font-medium opacity-60">Vroömly v2.2.0 • Bahria Campus</p>
          </div>
        </div>
      </div>
    </>
  );
};
