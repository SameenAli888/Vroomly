import React from 'react';
import { LocationPoint } from '../types';
import { MapPin, Car } from 'lucide-react';

interface RideMapProps {
  route: LocationPoint[];
  currentStep: number;
}

export const RideMap: React.FC<RideMapProps> = ({ route, currentStep }) => {
  const progress = (currentStep / (route.length - 1)) * 100;
  const segmentsLeft = route.length - 1 - currentStep;
  const etaMinutes = segmentsLeft * 5;

  return (
    <div className="bg-white rounded-[32px] shadow-card border border-white/60 overflow-hidden relative">
      {/* Map Header */}
      <div className="absolute top-0 left-0 right-0 p-5 flex justify-between items-start z-20">
        <div className="bg-white/90 backdrop-blur-md px-4 py-2 rounded-2xl shadow-sm border border-gray-100">
           <h3 className="text-xs font-extrabold text-bahria-blue uppercase tracking-wider flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            Live Tracking
          </h3>
        </div>
        <div className="bg-bahria-blue text-white px-3 py-1.5 rounded-xl shadow-lg shadow-bahria-blue/20">
           <span className="text-xs font-bold">ETA: {etaMinutes}m</span>
        </div>
      </div>

      {/* Visual Map Area */}
      <div className="relative pt-20 pb-8 px-8 bg-slate-50 min-h-[300px] flex flex-col justify-center overflow-hidden">
        {/* Decorative Grid */}
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'linear-gradient(#002147 1px, transparent 1px), linear-gradient(90deg, #002147 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
        
        {/* The Track Line Container */}
        <div className="absolute left-10 top-20 bottom-10 w-3 bg-gray-200 rounded-full overflow-hidden shadow-inner">
           {/* Animated Gradient Fill */}
           <div 
            className="w-full bg-gradient-to-b from-bahria-gold to-bahria-blue transition-all duration-1000 ease-in-out shadow-[0_0_15px_rgba(0,33,71,0.5)]"
            style={{ height: `${Math.min(progress, 100)}%` }}
          ></div>
        </div>

        {/* The Car - Animated */}
        <div 
          className="absolute left-[24px] z-10 transition-all duration-1000 ease-in-out will-change-transform"
          style={{ top: `${20 + (progress * 0.65)}%` }} 
        >
          <div className="bg-white p-2.5 rounded-full shadow-float border-2 border-white ring-4 ring-bahria-blue/10 animate-drive">
             <Car size={20} className="text-bahria-blue fill-bahria-blue" />
          </div>
        </div>

        {/* Route Points */}
        <div className="space-y-10 relative z-0 mt-4">
          {route.map((point, index) => {
             const isPast = index <= currentStep;
             const isCurrent = index === currentStep;
             const isLast = index === route.length - 1;
             
             return (
               <div key={point.id} className="flex items-center ml-12 relative group">
                  {/* Dot */}
                  <div className={`
                    absolute -left-[43px] w-5 h-5 rounded-full border-[4px] box-content transition-all duration-500 z-0
                    ${isPast ? 'bg-bahria-blue border-white shadow-md' : 'bg-gray-100 border-gray-300'}
                    ${isCurrent ? 'scale-110 ring-4 ring-bahria-gold/30 !bg-bahria-gold !border-white' : ''}
                  `}>
                  </div>
                  
                  {/* Label Card */}
                  <div className={`
                    pl-5 pr-4 py-3 rounded-2xl transition-all duration-500 w-full border
                    ${isCurrent 
                      ? 'bg-white border-bahria-blue/10 shadow-lg scale-105 translate-x-2' 
                      : 'bg-white/40 border-transparent scale-100 opacity-60'}
                  `}>
                    <p className={`text-sm font-bold ${isCurrent ? 'text-bahria-blue' : 'text-gray-500'}`}>
                      {point.name}
                    </p>
                    {isCurrent && (
                      <p className="text-[10px] text-bahria-gold font-bold uppercase tracking-wider mt-1 flex items-center gap-1">
                        <MapPin size={10} /> Current Stop
                      </p>
                    )}
                    {isLast && !isCurrent && (
                      <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mt-1">Destination</p>
                    )}
                  </div>
               </div>
             );
          })}
        </div>
      </div>
    </div>
  );
};