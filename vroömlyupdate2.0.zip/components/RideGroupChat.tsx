
import React, { useState, useRef, useEffect } from 'react';
import { Send, X, MessageSquare, Car, User, Crown } from 'lucide-react';
import { GroupMessage, User as UserType } from '../types';

interface RideGroupChatProps {
  currentUser: UserType;
  messages: GroupMessage[];
  onSendMessage: (text: string) => void;
}

export const RideGroupChat: React.FC<RideGroupChatProps> = ({ 
  currentUser, 
  messages, 
  onSendMessage 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSend = () => {
    if (!input.trim()) return;
    onSendMessage(input);
    setInput('');
  };

  const formatTime = (isoString: string) => {
    const date = new Date(isoString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="fixed bottom-4 left-4 z-50">
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="relative bg-truck-teal hover:bg-teal-700 text-white p-4 rounded-full shadow-lg transition-transform transform hover:scale-105 border-2 border-white"
        >
          <MessageSquare className="w-6 h-6" />
          {messages.length > 0 && (
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
              {messages.length}
            </span>
          )}
        </button>
      )}

      {isOpen && (
        <div className="bg-white rounded-2xl shadow-2xl w-80 sm:w-96 flex flex-col border border-gray-200 overflow-hidden animate-fade-in-up">
          {/* Header */}
          <div className="bg-truck-teal p-4 flex justify-between items-center text-white">
            <h3 className="font-bold flex items-center">
              <span className="text-xl mr-2">🚐</span> Ride Group Chat
            </h3>
            <button onClick={() => setIsOpen(false)} className="hover:bg-white/20 rounded-full p-1">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 h-80 overflow-y-auto p-4 space-y-4 bg-gray-50 scrollbar-hide">
            {messages.map((msg) => {
              const isMe = msg.senderId === currentUser.id;
              const isDriver = msg.role === 'DRIVER';
              // Note: In a real app, we'd look up the user object to check 'isPremium'. 
              // For now, let's assume if it's the current user and they are premium, we show it.
              // For other users in the chat, we'd need their user object available in the messages or looked up.
              // We'll simulate it for the current user.
              const isPremium = isMe ? currentUser.isPremium : false; 

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                >
                  <div className={`flex items-end gap-2 max-w-[85%] ${isMe ? 'flex-row-reverse' : 'flex-row'}`}>
                    {/* Avatar Bubble */}
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 shadow-sm relative
                      ${isMe ? 'bg-green-100 text-pak-green' : isDriver ? 'bg-yellow-100 text-yellow-800' : 'bg-pink-100 text-truck-pink'}
                      ${isPremium ? 'border-2 border-bahria-gold' : ''}`}
                    >
                      {isDriver ? <Car size={14} /> : <User size={14} />}
                      {isPremium && <div className="absolute -top-2 -right-1 text-bahria-gold"><Crown size={10} fill="currentColor" /></div>}
                    </div>

                    {/* Message Bubble */}
                    <div
                      className={`px-4 py-2 rounded-2xl text-sm shadow-sm relative
                        ${isMe 
                          ? 'bg-pak-green text-white rounded-br-none' 
                          : isDriver 
                            ? 'bg-truck-yellow text-black rounded-bl-none border border-yellow-300' 
                            : 'bg-white text-gray-800 border border-gray-200 rounded-bl-none'
                        }
                        ${isPremium && isMe ? 'border-2 border-bahria-gold/50' : ''}`}
                    >
                      {!isMe && (
                        <p className={`text-[10px] font-bold mb-0.5 ${isDriver ? 'text-yellow-900' : 'text-gray-500'}`}>
                          {msg.senderName} {isDriver && '★ Captain'}
                        </p>
                      )}
                      {msg.text}
                      <p className={`text-[9px] mt-1 text-right ${isMe ? 'text-green-200' : 'text-gray-400'}`}>
                        {formatTime(msg.timestamp)}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-3 bg-white border-t border-gray-100 flex items-center gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Message everyone..."
              className="flex-1 border border-gray-300 rounded-full px-4 py-2 text-sm focus:outline-none focus:border-truck-teal focus:ring-1 focus:ring-truck-teal text-gray-900"
            />
            <button 
              onClick={handleSend}
              disabled={!input.trim()}
              className="bg-truck-teal text-white p-2 rounded-full hover:bg-teal-800 disabled:opacity-50 transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
