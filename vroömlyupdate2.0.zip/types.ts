
export type UserRole = 'DRIVER' | 'PASSENGER';

export type PassengerStatus = 'PENDING' | 'COMING' | 'PRESENT' | 'ABSENT';

export type RideStatus = 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED';

export type RideDirection = 'TO_CAMPUS' | 'FROM_CAMPUS';

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string; // Simulated auth
  role: UserRole;
  avatar: string; 
  averageRating: number;
  totalReviews: number;
  totalRides: number; // Added attribute for tracking completed rides
  phone?: string;
  isPremium?: boolean; // New Premium Flag
  premiumExpiry?: string; // Expiration date for premium subscription
  preferences?: {
    frontSeat: boolean;
    quietRide: boolean;
    genderFilter: boolean;
  };
}

export interface Passenger extends User {
  status: PassengerStatus;
  pickupLocation: string;
}

export interface GroupMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: string;
  role: UserRole;
  isAlert?: boolean; // Added for identifying alerts in chat
}

export interface Review {
  id: string;
  reviewerId: string;
  revieweeId: string;
  rating: number; // 1-5
  comment: string;
  timestamp: string;
}

export interface Cancellation {
  userId: string;
  userName: string;
  reason: string;
  timestamp: string;
}

export interface Complaint {
  id: string;
  userId: string;
  userName: string;
  category: string;
  details: string;
  timestamp: string;
  status: 'PENDING' | 'RESOLVED';
}

export interface LocationPoint {
  id: string;
  name: string; 
  lat: number;
  lng: number;
  isStop: boolean;
}

export interface RouteDefinition {
  id: string;
  name: string;
  points: LocationPoint[];
}

export interface Alert {
  id: string;
  text: string;
  time: string;
  type: 'DELAY' | 'ARRIVAL' | 'EMERGENCY' | 'INFO';
}

export interface Ride {
  id: string;
  driverId: string;
  direction: RideDirection;
  vehicleName: string; 
  vehicleType: 'SEDAN' | 'HI_ROOF' | 'BUS' | 'HATCHBACK';
  capacity: number;
  routeId: string;
  startTime: string;
  passengers: Passenger[];
  isActive: boolean;
  status: RideStatus;
  currentLocationIndex: number; 
  chatMessages: GroupMessage[];
  reviews: Review[];
  cancellations?: Cancellation[];
  latestAlert?: Alert;
  completedAt?: string; // Added for history tracking
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface AppSettings {
  notifications: boolean;
  language: 'English' | 'Urdu';
  twoFactorAuth: boolean;
}
